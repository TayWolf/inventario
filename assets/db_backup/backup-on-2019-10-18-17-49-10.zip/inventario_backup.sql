#
# TABLE STRUCTURE FOR: antivirus
#

DROP TABLE IF EXISTS `antivirus`;

CREATE TABLE `antivirus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(250) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `antivirus` (`id`, `descripcion`, `estado`) VALUES ('1', 'WINDOWS DEFENDER', '1');


#
# TABLE STRUCTURE FOR: areas
#

DROP TABLE IF EXISTS `areas`;

CREATE TABLE `areas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

INSERT INTO `areas` (`id`, `nombre`, `estado`) VALUES ('1', 'DIRECCIÓN DE FOMENTO A PROYECTOS Y COINVERSIONES', '1');
INSERT INTO `areas` (`id`, `nombre`, `estado`) VALUES ('2', 'DIRECCIÓN DE ADMINISTRACIÓN Y FINANZAS', '1');
INSERT INTO `areas` (`id`, `nombre`, `estado`) VALUES ('3', 'DIRECCIÓN GENERAL', '1');
INSERT INTO `areas` (`id`, `nombre`, `estado`) VALUES ('4', 'INFORMÁTICA', '1');
INSERT INTO `areas` (`id`, `nombre`, `estado`) VALUES ('5', 'SNCA/JÓVENES CREADORES/CREADORES ESCÉNICOS', '1');
INSERT INTO `areas` (`id`, `nombre`, `estado`) VALUES ('6', 'EVALUACIÓN', '1');
INSERT INTO `areas` (`id`, `nombre`, `estado`) VALUES ('7', 'PROMOSIÓN Y DIFUSIÓN', '1');
INSERT INTO `areas` (`id`, `nombre`, `estado`) VALUES ('8', 'COORDINACIÓN JURÍDICA', '1');
INSERT INTO `areas` (`id`, `nombre`, `estado`) VALUES ('9', 'ACCIÓN INTERNACIONAL', '1');
INSERT INTO `areas` (`id`, `nombre`, `estado`) VALUES ('15', 'FONCA-VIGILANCIA', '1');
INSERT INTO `areas` (`id`, `nombre`, `estado`) VALUES ('16', 'EN ALMACÉN', '1');


#
# TABLE STRUCTURE FOR: cargos
#

DROP TABLE IF EXISTS `cargos`;

CREATE TABLE `cargos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(250) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: categoria
#

DROP TABLE IF EXISTS `categoria`;

CREATE TABLE `categoria` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(100) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `categoria` (`id`, `descripcion`, `estado`) VALUES ('1', 'Equipo de escritorio', '1');
INSERT INTO `categoria` (`id`, `descripcion`, `estado`) VALUES ('2', 'Lap-Top', '1');


#
# TABLE STRUCTURE FOR: computadoras
#

DROP TABLE IF EXISTS `computadoras`;

CREATE TABLE `computadoras` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(11) NOT NULL,
  `monitor_id` int(11) NOT NULL,
  `presentacion_id` int(11) NOT NULL,
  `proveedor_id` int(11) NOT NULL,
  `finca_id` int(11) NOT NULL,
  `area_id` int(11) NOT NULL,
  `id_propietario` int(11) NOT NULL,
  `contacto` varchar(250) NOT NULL,
  `fabricante_id` int(11) NOT NULL,
  `procesador_id` int(11) NOT NULL,
  `ram_id` int(11) NOT NULL,
  `disco_id` int(11) NOT NULL,
  `so_id` int(11) NOT NULL,
  `serial_so` varchar(110) NOT NULL,
  `office_id` int(11) NOT NULL,
  `serial_office` varchar(110) NOT NULL,
  `antivirus_id` int(11) NOT NULL,
  `ip_id` int(4) NOT NULL,
  `mac` varchar(50) NOT NULL,
  `bitacora` text NOT NULL,
  `estado` tinyint(1) NOT NULL,
  `ultimo_mante` date DEFAULT NULL,
  `fecregistro` datetime NOT NULL,
  `usuario_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=174 DEFAULT CHARSET=latin1;

INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('1', 'MJ06J8E8', '1', '1', '2', '2', '9', '1', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '16', '60:40:90:40:72:07', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('2', 'MJ06JYH6', '2', '1', '2', '2', '16', '2', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '68', '60:40:90:40:72:08', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('3', 'MJ06J8GX', '3', '1', '2', '2', '9', '3', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '50', '60:40:90:40:72:09', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('4', 'MJ06J8GU', '4', '1', '2', '2', '9', '4', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '99', '60:40:90:40:72:10', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('5', 'MJ06J8EV', '5', '1', '2', '2', '6', '5', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '81', '60:40:90:40:72:11', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('6', 'MJ06J8H9', '6', '1', '2', '2', '5', '6', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '38', '60:40:90:40:72:12', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('7', 'MJ06JYDS', '7', '1', '2', '2', '16', '7', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '130', '60:40:90:40:72:13', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('8', 'MJ06J8EW', '8', '1', '2', '2', '8', '8', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '132', '60:40:90:40:72:14', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('9', 'MJ06JYDT', '9', '1', '2', '2', '16', '9', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '49', '60:40:90:40:72:15', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('10', 'MJ06J8HD', '10', '1', '2', '2', '1', '10', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '58', '60:40:90:40:72:16', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('11', 'MJ06J8A8', '11', '1', '2', '2', '5', '11', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '112', '60:40:90:40:72:17', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('12', 'MJ06JYHT', '12', '1', '2', '2', '16', '12', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '31', '60:40:90:40:72:18', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('13', 'MJ06JYHN', '13', '1', '2', '2', '5', '13', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '33', '60:40:90:40:72:19', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('14', 'MJ06J8HC', '14', '1', '2', '2', '5', '14', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '123', '60:40:90:40:72:20', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('15', 'MJ06J8EQ', '15', '1', '2', '2', '5', '15', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '98', '60:40:90:40:72:21', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('16', 'MJ06J6GZ', '16', '1', '2', '2', '5', '16', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '29', '60:40:90:40:72:22', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('17', 'MJ06J8D4', '17', '1', '2', '2', '16', '17', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '200', '60:40:90:40:72:23', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('18', 'MJ06J8H7', '18', '1', '2', '2', '16', '18', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '82', '60:40:90:40:72:24', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('19', 'MJ06J8FM', '19', '1', '2', '2', '5', '19', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '74', '60:40:90:40:72:25', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('20', 'MJ06J8GW', '20', '1', '2', '2', '5', '20', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '13', '60:40:90:40:72:26', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('21', 'MJ06J8HB', '21', '1', '2', '2', '5', '21', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '60', '60:40:90:40:72:27', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('22', 'MJ06J8KD', '22', '1', '2', '2', '5', '22', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '117', '60:40:90:40:72:28', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('23', 'MJ06J8FE', '23', '1', '2', '2', '5', '23', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '87', '60:40:90:40:72:29', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('24', 'MJ06JYHJ', '24', '1', '2', '2', '5', '24', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '101', '60:40:90:40:72:30', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('25', 'MJ06JYHX', '25', '1', '2', '2', '5', '25', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '141', '60:40:90:40:72:31', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('26', 'MJ06JYE0', '26', '1', '2', '2', '5', '26', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '41', '60:40:90:40:72:32', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('27', 'MJ06J8FF', '27', '1', '2', '2', '5', '27', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '56', '60:40:90:40:72:33', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('28', 'MJ06JYHB', '28', '1', '2', '2', '16', '28', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '121', '60:40:90:40:72:34', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('29', 'MJ06J8H1', '29', '1', '2', '2', '1', '29', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '155', '60:40:90:40:72:35', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('30', 'MJ06J6F5', '30', '1', '2', '2', '1', '30', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '146', '60:40:90:40:72:36', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('31', 'MJ06J6G0', '31', '1', '2', '2', '1', '31', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '150', '60:40:90:40:72:37', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('32', 'MJ06J8B3', '32', '1', '2', '2', '1', '32', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '173', '60:40:90:40:72:38', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('33', 'MJ06J8ML', '33', '1', '2', '2', '1', '33', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '71', '60:40:90:40:72:39', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('34', 'MJ06J8MM', '34', '1', '2', '2', '1', '34', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '144', '60:40:90:40:72:40', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('35', 'MJ06J8B4', '35', '1', '2', '2', '1', '35', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '133', '60:40:90:40:72:41', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('36', 'MJ06J8BA', '36', '1', '2', '2', '1', '36', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '156', '60:40:90:40:72:42', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('37', 'MJ06J8D1', '37', '1', '2', '2', '1', '37', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '152', '60:40:90:40:72:43', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('38', 'MJ06J8FC', '38', '1', '2', '2', '1', '38', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '148', '60:40:90:40:72:44', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('39', 'MJ06J8MN', '39', '1', '2', '2', '4', '39', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '17', '60:40:90:40:72:45', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('40', 'MJ06J6FL', '40', '1', '2', '2', '4', '40', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '164', '60:40:90:40:72:46', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('41', 'MJ06J6G1', '41', '1', '2', '2', '4', '41', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '78', '60:40:90:40:72:47', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('42', 'MJ06J6G7', '42', '1', '2', '2', '4', '42', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '48', '60:40:90:40:72:48', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('43', 'MJ06J8B2', '43', '1', '2', '2', '5', '43', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '124', '60:40:90:40:72:49', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('44', 'MJ06J6EY', '44', '1', '2', '2', '6', '44', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '59', '60:40:90:40:72:50', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('45', 'MJ06J6FH', '45', '1', '2', '2', '16', '45', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '158', '60:40:90:40:72:51', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('46', 'MJ06J8FH', '46', '1', '2', '2', '16', '46', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '79', '60:40:90:40:72:52', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('47', 'MJ06JZ11', '47', '1', '2', '2', '16', '47', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '77', '60:40:90:40:72:53', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('48', 'MJ06J6FX', '48', '1', '2', '2', '5', '48', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '80', '60:40:90:40:72:54', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('49', 'MJ06J8MQ', '49', '1', '2', '2', '5', '49', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '90', '60:40:90:40:72:55', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('50', 'MJ06J6F7', '50', '1', '2', '2', '5', '50', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '151', '60:40:90:40:72:56', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('51', 'MJ06J6HY', '51', '1', '2', '2', '2', '51', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '21', '60:40:90:40:72:57', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('52', 'MJ06J6F1', '52', '1', '2', '2', '16', '52', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '45', '60:40:90:40:72:58', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('53', 'MJ06J8AP', '53', '1', '2', '2', '4', '53', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '43', '60:40:90:40:72:59', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('54', 'MJ06J6F6', '54', '1', '2', '2', '2', '54', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '106', '60:40:90:40:72:60', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('55', 'MJ06J8FG', '55', '1', '2', '2', '2', '55', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '51', '60:40:90:40:72:61', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('56', 'MJ06J8EY', '56', '1', '2', '2', '2', '56', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '107', '60:40:90:40:72:62', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('57', 'MJ06J6JB', '57', '1', '2', '2', '2', '57', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '40', '60:40:90:40:72:63', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('58', 'MJ06J6BB', '58', '1', '2', '2', '2', '58', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '28', '60:40:90:40:72:64', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('59', 'MJ06J6B9', '59', '1', '2', '2', '2', '59', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '35', '60:40:90:40:72:65', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('60', 'MJ06J6JL', '60', '1', '2', '2', '2', '60', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '47', '60:40:90:40:72:66', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('61', 'MJ06J6PF', '61', '1', '2', '2', '2', '61', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '42', '60:40:90:40:72:67', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('62', 'MJ06J67D', '62', '1', '2', '2', '2', '62', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '24', '60:40:90:40:72:68', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('63', 'MJ06J6JA', '63', '1', '2', '2', '2', '63', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '110', '60:40:90:40:72:69', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('64', 'MJ06J6JD', '64', '1', '2', '2', '2', '64', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '57', '60:40:90:40:72:70', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('65', 'MJ06J6GT', '65', '1', '2', '2', '2', '65', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '88', '60:40:90:40:72:71', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('66', 'MJ06J6JQ', '66', '1', '2', '2', '2', '66', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '86', '60:40:90:40:72:72', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('67', 'MJ06J6JG', '67', '1', '2', '2', '9', '67', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '84', '60:40:90:40:72:73', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('68', 'MJ06J6J0', '68', '1', '2', '2', '2', '68', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '91', '60:40:90:40:72:74', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('69', 'MJ06JYGC', '69', '1', '2', '2', '2', '69', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '83', '60:40:90:40:72:75', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('70', 'MJ06JYXM', '70', '1', '2', '2', '2', '70', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '26', '60:40:90:40:72:76', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('71', 'MJ06JWDP', '71', '1', '2', '2', '16', '71', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '27', '60:40:90:40:72:77', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('72', 'MJ06JWE3', '72', '1', '2', '2', '2', '72', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '25', '60:40:90:40:72:78', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('73', 'MJ06JWHY', '73', '1', '2', '2', '2', '73', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '32', '60:40:90:40:72:79', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('74', 'MJ06J8KA', '74', '1', '2', '2', '2', '74', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '34', '60:40:90:40:72:80', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('75', 'MJ06JYGA', '75', '1', '2', '2', '16', '75', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '129', '60:40:90:40:72:81', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('76', 'MJ06J6RN', '76', '1', '2', '2', '2', '76', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '65', '60:40:90:40:72:82', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('77', 'MJ06J6L1', '77', '1', '2', '2', '2', '77', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '85', '60:40:90:40:72:83', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('78', 'MJ06JWDF', '78', '1', '2', '2', '2', '78', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '75', '60:40:90:40:72:84', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('79', 'MJ06JYZZ', '79', '1', '2', '2', '2', '79', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '53', '60:40:90:40:72:85', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('80', 'MJ06JYM3', '80', '1', '2', '2', '2', '80', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '66', '60:40:90:40:72:86', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('81', 'MJ06J6BE', '81', '1', '2', '2', '2', '81', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '122', '60:40:90:40:72:87', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('82', 'MJ06JYJ5', '82', '1', '2', '2', '8', '82', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '100', '60:40:90:40:72:88', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('83', 'MJ06J692', '83', '1', '2', '2', '16', '83', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '73', '60:40:90:40:72:89', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('84', 'MJ06J68F', '84', '1', '2', '2', '6', '84', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '61', '60:40:90:40:72:90', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('85', 'MJ06J699', '85', '1', '2', '2', '6', '85', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '138', '60:40:90:40:72:91', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('86', 'MJ06J698', '86', '1', '2', '2', '6', '86', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '111', '60:40:90:40:72:92', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('87', 'MJ06J6D1', '87', '1', '2', '2', '6', '87', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '125', '60:40:90:40:72:93', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('88', 'MJ06J6VE', '88', '1', '2', '2', '6', '88', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '114', '60:40:90:40:72:94', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('89', 'MJ06J6UL', '89', '1', '2', '2', '8', '89', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '18', '60:40:90:40:72:95', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('90', 'MJ06J6HL', '90', '1', '2', '2', '8', '90', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '22', '60:40:90:40:72:96', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('91', 'MJ06J6JF', '91', '1', '2', '2', '8', '91', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '67', '60:40:90:40:72:97', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('92', 'MJ06J6AP', '92', '1', '2', '2', '8', '92', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '93', '60:40:90:40:72:98', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('93', 'MJ06J6HP', '93', '1', '2', '2', '8', '93', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '95', '60:40:90:40:72:99', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('94', 'MJ06J6AN', '94', '1', '2', '2', '8', '94', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '131', '60:40:90:40:72:100', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('95', 'MJ06J6AU', '95', '1', '2', '2', '8', '95', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '113', '60:40:90:40:72:101', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('96', 'MJ06J6B2', '96', '1', '2', '2', '8', '96', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '46', '60:40:90:40:72:102', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('97', 'MJ06JYWY', '97', '1', '2', '2', '8', '97', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '102', '60:40:90:40:72:103', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('98', 'MJ06JYSY', '98', '1', '2', '2', '8', '98', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '119', '60:40:90:40:72:104', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('99', 'MJ06JWFC', '99', '1', '2', '2', '8', '99', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '54', '60:40:90:40:72:105', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('100', 'MJ06JYPL', '100', '1', '2', '2', '8', '100', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '127', '60:40:90:40:72:106', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('101', 'MJ06JYQ4', '101', '1', '2', '2', '8', '101', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '128', '60:40:90:40:72:107', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('102', 'MJ06JWMM', '102', '1', '2', '2', '8', '102', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '36', '60:40:90:40:72:108', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('103', 'MJ06J6N4', '103', '1', '2', '2', '2', '103', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '15', '60:40:90:40:72:109', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('104', 'MJ06J8G4', '104', '1', '2', '2', '3', '104', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '39', '60:40:90:40:72:110', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('105', 'MJ06J8EA', '105', '1', '2', '2', '16', '105', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '135', '60:40:90:40:72:111', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('106', 'MJ06J8LD', '106', '1', '2', '2', '6', '106', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '62', '60:40:90:40:72:112', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('107', 'MJ06J6PS', '107', '1', '2', '2', '2', '107', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '19', '60:40:90:40:72:113', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('108', 'MJ06J6P0', '108', '1', '2', '2', '3', '108', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '104', '60:40:90:40:72:114', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('109', 'MJ06J6HV', '109', '1', '2', '2', '16', '109', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '178', '60:40:90:40:72:115', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('110', 'MJ06J6BH', '110', '1', '2', '2', '3', '110', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '14', '60:40:90:40:72:116', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('111', 'MJ06JYMU', '111', '1', '2', '2', '7', '111', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '120', '60:40:90:40:72:117', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('112', 'MJ06JYK9', '112', '1', '2', '2', '4', '112', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '72', '60:40:90:40:72:118', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('113', 'MJ06JYNS', '113', '1', '2', '2', '7', '113', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '52', '60:40:90:40:72:119', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('114', 'MJ06JYYW', '114', '1', '2', '2', '7', '114', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '94', '60:40:90:40:72:120', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('115', 'MJ06JYGW', '115', '1', '2', '2', '4', '115', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '92', '60:40:90:40:72:121', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('116', 'MJ06JYGH', '116', '1', '2', '2', '6', '116', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '136', '60:40:90:40:72:122', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('117', 'MJ06JWJC', '117', '1', '2', '2', '16', '117', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '134', '60:40:90:40:72:123', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('118', 'MJ06JWGQ', '118', '1', '2', '2', '2', '118', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '143', '60:40:90:40:72:124', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('119', 'MJ06JYHF', '119', '1', '2', '2', '4', '119', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '69', '60:40:90:40:72:125', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('120', 'MJ06JYH7', '120', '1', '2', '2', '4', '120', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '70', '60:40:90:40:72:126', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('121', 'MJ06JYNZ', '121', '1', '2', '2', '4', '121', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '168', '60:40:90:40:72:127', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('122', 'MJ06J6FC', '122', '1', '2', '2', '2', '122', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '147', '60:40:90:40:72:128', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('123', 'MJ06JWN0', '123', '1', '2', '2', '4', '123', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '20', '60:40:90:40:72:129', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('124', 'MJ06JYUR', '124', '1', '2', '2', '4', '124', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '140', '60:40:90:40:72:130', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('125', 'MJ06JYF2', '125', '1', '2', '2', '4', '125', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '37', '60:40:90:40:72:131', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('126', 'MJ06J8JL', '126', '1', '2', '2', '4', '126', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '177', '60:40:90:40:72:132', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('127', 'MJ06J6U6', '127', '1', '2', '2', '1', '127', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '0', '60:40:90:40:72:133', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('128', 'MJ06JZRV', '128', '1', '2', '2', '9', '128', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '118', '60:40:90:40:72:134', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('129', 'MJ06JZT1', '129', '1', '2', '2', '4', '129', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '9', '60:40:90:40:72:135', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('130', 'MJ06JZPY', '130', '1', '2', '2', '4', '130', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '4', '60:40:90:40:72:136', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('131', 'MJ06JZSP', '131', '1', '2', '2', '4', '131', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '159', '60:40:90:40:72:137', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('132', 'MJ06J7W8', '132', '1', '2', '2', '9', '132', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '96', '60:40:90:40:72:138', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('133', 'MJ06JZSG', '133', '1', '2', '2', '5', '133', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '162', '60:40:90:40:72:139', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('134', 'MJ06JYP6', '134', '1', '2', '2', '2', '134', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '105', '60:40:90:40:72:140', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('135', 'MJ06JYQK', '135', '1', '2', '2', '2', '135', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '142', '60:40:90:40:72:141', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('136', 'MJ06JYEY', '136', '1', '2', '2', '5', '136', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '63', '60:40:90:40:72:142', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('137', 'MJ06JYP2', '137', '1', '2', '2', '5', '137', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '76', '60:40:90:40:72:143', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('138', 'MJ06JYNW', '138', '1', '2', '2', '5', '138', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '55', '60:40:90:40:72:144', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('139', 'MJ06JYQT', '139', '1', '2', '2', '2', '139', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '0', '60:40:90:40:72:145', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('140', 'MJ06JYJ8', '140', '1', '2', '2', '1', '140', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '149', '60:40:90:40:72:146', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('141', 'MJ06JYGN', '141', '1', '2', '2', '4', '141', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '0', '60:40:90:40:72:147', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('142', 'MJ06JZ1C', '142', '1', '2', '2', '4', '142', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '0', '60:40:90:40:72:148', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('143', 'MJ06JWNE', '143', '1', '2', '2', '4', '143', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '0', '60:40:90:40:72:149', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('144', 'MJ06J8AH', '144', '1', '2', '2', '4', '144', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '0', '60:40:90:40:72:150', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('145', 'MJ06JYPN', '145', '1', '2', '2', '2', '145', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '0', '60:40:90:40:72:151', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('146', 'MJ06JYP8', '146', '1', '2', '2', '4', '146', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '0', '60:40:90:40:72:152', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `id_propietario`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('147', 'MJ06JYP7', '147', '1', '2', '2', '4', '147', 'FONCA', '1', '1', '2', '2', '2', '1000', '2', '2000', '1', '0', '60:40:90:40:72:153', 'OK', '1', NULL, '0000-00-00 00:00:00', '3');


#
# TABLE STRUCTURE FOR: computadoras_mantenimientos
#

DROP TABLE IF EXISTS `computadoras_mantenimientos`;

CREATE TABLE `computadoras_mantenimientos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `computadora_id` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `tecnico` varchar(250) NOT NULL,
  `descripcion` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: discos
#

DROP TABLE IF EXISTS `discos`;

CREATE TABLE `discos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `capacidad` varchar(250) NOT NULL,
  `fabricante_id` int(11) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `discos` (`id`, `capacidad`, `fabricante_id`, `estado`) VALUES ('1', '250 GB', '1', '1');
INSERT INTO `discos` (`id`, `capacidad`, `fabricante_id`, `estado`) VALUES ('2', '500 GB', '1', '1');
INSERT INTO `discos` (`id`, `capacidad`, `fabricante_id`, `estado`) VALUES ('3', '1 TB', '1', '1');


#
# TABLE STRUCTURE FOR: elemento
#

DROP TABLE IF EXISTS `elemento`;

CREATE TABLE `elemento` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nit` int(11) NOT NULL,
  `nombre` varchar(250) NOT NULL,
  `direccion` varchar(250) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `descripcion` text NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `elemento` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('1', '1000', 'Propio', 'Calle Parque Lira S/N, Bosque de Chapultepec I Secc, 11850 Ciudad de México, CDMX', '55-29-52-07-90', 'FONCA', '1');
INSERT INTO `elemento` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('2', '1001', 'Arrendado', 'Calle Gabriel Mancera 1306, Col. del Valle Sur, 03100 Ciudad de México, CDMX', '55 52-67-34-00', 'MainBit', '1');


#
# TABLE STRUCTURE FOR: fabricantes
#

DROP TABLE IF EXISTS `fabricantes`;

CREATE TABLE `fabricantes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(250) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `fabricantes` (`id`, `nombre`, `estado`) VALUES ('1', 'LENOVO', '1');
INSERT INTO `fabricantes` (`id`, `nombre`, `estado`) VALUES ('2', 'MAC', '1');


#
# TABLE STRUCTURE FOR: impresoras
#

DROP TABLE IF EXISTS `impresoras`;

CREATE TABLE `impresoras` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proveedor_id` int(11) NOT NULL,
  `finca_id` int(11) NOT NULL,
  `area_id` int(11) NOT NULL,
  `contacto` varchar(150) NOT NULL,
  `fabricante_id` int(11) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `serial_fabricante` int(11) NOT NULL,
  `bitacora` text NOT NULL,
  `codigo` int(11) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  `ultimo_mante` date DEFAULT NULL,
  `fecregistro` datetime NOT NULL,
  `usuario_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: impresoras_mantenimientos
#

DROP TABLE IF EXISTS `impresoras_mantenimientos`;

CREATE TABLE `impresoras_mantenimientos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `impresora_id` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `tecnico` varchar(250) NOT NULL,
  `descripcion` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: ip
#

DROP TABLE IF EXISTS `ip`;

CREATE TABLE `ip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(250) NOT NULL,
  `id_codigo` int(11) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=256 DEFAULT CHARSET=latin1;

INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('1', '172.17.124.1', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('2', '172.17.124.2', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('3', '172.17.124.3', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('4', '172.17.124.4', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('5', '172.17.124.5', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('6', '172.17.124.6', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('7', '172.17.124.7', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('8', '172.17.124.8', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('9', '172.17.124.9', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('10', '172.17.124.10', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('11', '172.17.124.11', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('12', '172.17.124.12', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('13', '172.17.124.13', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('14', '172.17.124.14', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('15', '172.17.124.15', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('16', '172.17.124.16', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('17', '172.17.124.17', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('18', '172.17.124.18', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('19', '172.17.124.19', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('20', '172.17.124.20', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('21', '172.17.124.21', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('22', '172.17.124.22', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('23', '172.17.124.23', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('24', '172.17.124.24', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('25', '172.17.124.25', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('26', '172.17.124.26', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('27', '172.17.124.27', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('28', '172.17.124.28', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('29', '172.17.124.29', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('30', '172.17.124.30', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('31', '172.17.124.31', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('32', '172.17.124.32', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('33', '172.17.124.33', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('34', '172.17.124.34', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('35', '172.17.124.35', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('36', '172.17.124.36', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('37', '172.17.124.37', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('38', '172.17.124.38', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('39', '172.17.124.39', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('40', '172.17.124.40', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('41', '172.17.124.41', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('42', '172.17.124.42', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('43', '172.17.124.43', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('44', '172.17.124.44', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('45', '172.17.124.45', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('46', '172.17.124.46', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('47', '172.17.124.47', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('48', '172.17.124.48', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('49', '172.17.124.49', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('50', '172.17.124.50', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('51', '172.17.124.51', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('52', '172.17.124.52', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('53', '172.17.124.53', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('54', '172.17.124.54', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('55', '172.17.124.55', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('56', '172.17.124.56', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('57', '172.17.124.57', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('58', '172.17.124.58', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('59', '172.17.124.59', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('60', '172.17.124.60', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('61', '172.17.124.61', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('62', '172.17.124.62', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('63', '172.17.124.63', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('64', '172.17.124.64', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('65', '172.17.124.65', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('66', '172.17.124.66', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('67', '172.17.124.67', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('68', '172.17.124.68', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('69', '172.17.124.69', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('70', '172.17.124.70', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('71', '172.17.124.71', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('72', '172.17.124.72', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('73', '172.17.124.73', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('74', '172.17.124.74', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('75', '172.17.124.75', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('76', '172.17.124.76', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('77', '172.17.124.77', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('78', '172.17.124.78', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('79', '172.17.124.79', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('80', '172.17.124.80', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('81', '172.17.124.81', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('82', '172.17.124.82', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('83', '172.17.124.83', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('84', '172.17.124.84', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('85', '172.17.124.85', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('86', '172.17.124.86', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('87', '172.17.124.87', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('88', '172.17.124.88', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('89', '172.17.124.89', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('90', '172.17.124.90', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('91', '172.17.124.91', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('92', '172.17.124.92', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('93', '172.17.124.93', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('94', '172.17.124.94', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('95', '172.17.124.95', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('96', '172.17.124.96', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('97', '172.17.124.97', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('98', '172.17.124.98', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('99', '172.17.124.99', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('100', '172.17.124.100', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('101', '172.17.124.101', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('102', '172.17.124.102', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('103', '172.17.124.103', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('104', '172.17.124.104', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('105', '172.17.124.105', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('106', '172.17.124.106', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('107', '172.17.124.107', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('108', '172.17.124.108', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('109', '172.17.124.109', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('110', '172.17.124.110', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('111', '172.17.124.111', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('112', '172.17.124.112', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('113', '172.17.124.113', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('114', '172.17.124.114', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('115', '172.17.124.115', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('116', '172.17.124.116', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('117', '172.17.124.117', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('118', '172.17.124.118', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('119', '172.17.124.119', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('120', '172.17.124.120', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('121', '172.17.124.121', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('122', '172.17.124.122', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('123', '172.17.124.123', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('124', '172.17.124.124', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('125', '172.17.124.125', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('126', '172.17.124.126', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('127', '172.17.124.127', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('128', '172.17.124.128', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('129', '172.17.124.129', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('130', '172.17.124.130', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('131', '172.17.124.131', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('132', '172.17.124.132', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('133', '172.17.124.133', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('134', '172.17.124.134', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('135', '172.17.124.135', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('136', '172.17.124.136', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('137', '172.17.124.137', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('138', '172.17.124.138', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('139', '172.17.124.139', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('140', '172.17.124.140', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('141', '172.17.124.141', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('142', '172.17.124.142', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('143', '172.17.124.143', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('144', '172.17.124.144', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('145', '172.17.124.145', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('146', '172.17.124.146', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('147', '172.17.124.147', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('148', '172.17.124.148', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('149', '172.17.124.149', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('150', '172.17.124.150', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('151', '172.17.124.151', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('152', '172.17.124.152', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('153', '172.17.124.153', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('154', '172.17.124.154', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('155', '172.17.124.155', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('156', '172.17.124.156', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('157', '172.17.124.157', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('158', '172.17.124.158', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('159', '172.17.124.159', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('160', '172.17.124.160', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('161', '172.17.124.161', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('162', '172.17.124.162', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('163', '172.17.124.163', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('164', '172.17.124.164', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('165', '172.17.124.165', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('166', '172.17.124.166', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('167', '172.17.124.167', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('168', '172.17.124.168', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('169', '172.17.124.169', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('170', '172.17.124.170', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('171', '172.17.124.171', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('172', '172.17.124.172', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('173', '172.17.124.173', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('174', '172.17.124.174', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('175', '172.17.124.175', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('176', '172.17.124.176', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('177', '172.17.124.177', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('178', '172.17.124.178', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('179', '172.17.124.179', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('180', '172.17.124.180', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('181', '172.17.124.181', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('182', '172.17.124.182', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('183', '172.17.124.183', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('184', '172.17.124.184', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('185', '172.17.124.185', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('186', '172.17.124.186', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('187', '172.17.124.187', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('188', '172.17.124.188', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('189', '172.17.124.189', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('190', '172.17.124.190', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('191', '172.17.124.191', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('192', '172.17.124.192', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('193', '172.17.124.193', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('194', '172.17.124.194', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('195', '172.17.124.195', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('196', '172.17.124.196', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('197', '172.17.124.197', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('198', '172.17.124.198', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('199', '172.17.124.199', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('200', '172.17.124.200', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('201', '172.17.124.201', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('202', '172.17.124.202', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('203', '172.17.124.203', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('204', '172.17.124.204', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('205', '172.17.124.205', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('206', '172.17.124.206', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('207', '172.17.124.207', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('208', '172.17.124.208', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('209', '172.17.124.209', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('210', '172.17.124.210', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('211', '172.17.124.211', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('212', '172.17.124.212', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('213', '172.17.124.213', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('214', '172.17.124.214', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('215', '172.17.124.215', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('216', '172.17.124.216', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('217', '172.17.124.217', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('218', '172.17.124.218', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('219', '172.17.124.219', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('220', '172.17.124.220', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('221', '172.17.124.221', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('222', '172.17.124.222', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('223', '172.17.124.223', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('224', '172.17.124.224', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('225', '172.17.124.225', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('226', '172.17.124.226', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('227', '172.17.124.227', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('228', '172.17.124.228', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('229', '172.17.124.229', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('230', '172.17.124.230', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('231', '172.17.124.231', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('232', '172.17.124.232', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('233', '172.17.124.233', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('234', '172.17.124.234', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('235', '172.17.124.235', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('236', '172.17.124.236', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('237', '172.17.124.237', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('238', '172.17.124.238', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('239', '172.17.124.239', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('240', '172.17.124.240', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('241', '172.17.124.241', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('242', '172.17.124.242', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('243', '172.17.124.243', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('244', '172.17.124.244', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('245', '172.17.124.245', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('246', '172.17.124.246', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('247', '172.17.124.247', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('248', '172.17.124.248', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('249', '172.17.124.249', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('250', '172.17.124.250', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('251', '172.17.124.251', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('252', '172.17.124.252', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('253', '172.17.124.253', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('254', '172.17.124.254', '0', '0');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('255', '172.17.124.255', '0', '0');


#
# TABLE STRUCTURE FOR: lectores_mantenimientos
#

DROP TABLE IF EXISTS `lectores_mantenimientos`;

CREATE TABLE `lectores_mantenimientos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lector_id` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `tecnico` varchar(250) NOT NULL,
  `descripcion` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: logs
#

DROP TABLE IF EXISTS `logs`;

CREATE TABLE `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` datetime NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `modulo` varchar(200) NOT NULL,
  `accion` varchar(200) NOT NULL,
  `descripcion` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=latin1;

INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('1', '2019-10-07 19:09:19', '10', 'Fabricantes', '', 'Inserción del Fabricante  LENOVO');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('2', '2019-10-07 19:09:26', '10', 'Fabricantes', '', 'Inserción del Fabricante  MAC');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('3', '2019-10-07 19:16:21', '10', 'Fincas', '', 'Inserción de la Finca Propio');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('4', '2019-10-07 19:16:40', '10', 'Fincas', '', 'Actualización de la Finca Propio');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('5', '2019-10-07 19:29:05', '10', 'Fincas', '', 'Inserción de la Finca Arrendado');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('6', '2019-10-07 19:44:57', '10', 'Proveedores', '', 'Inserción de nuevo Proveedor con NIT 2000');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('7', '2019-10-07 19:49:39', '10', 'Office', '', 'Inserción de un nuevo Office con el nombre Office 2013');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('8', '2019-10-07 19:49:45', '10', 'Office', '', 'Actualización del Office con nombre Office 2010');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('9', '2019-10-07 19:49:54', '10', 'Office', '', 'Inserción de un nuevo Office con el nombre Office 2013');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('10', '2019-10-07 19:50:03', '10', 'Office', '', 'Inserción de un nuevo Office con el nombre Office 2016');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('11', '2019-10-07 19:50:48', '10', 'Memorias RAM', '', 'Inserción de Memoria RAM con capacidad de 4GB');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('12', '2019-10-07 19:50:58', '10', 'Memorias RAM', '', 'Inserción de Memoria RAM con capacidad de 8GB');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('13', '2019-10-07 19:51:10', '10', 'Memorias RAM', '', 'Inserción de Memoria RAM con capacidad de 12GB');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('14', '2019-10-07 19:54:45', '10', 'Procesadores', '', 'Inserción de nuevo Procesador  con velocidad de 3.50 GHZ');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('15', '2019-10-07 19:55:05', '10', 'Disco Duro', '', 'Inserción del Disco Duro con capacidad de 500 GB');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('16', '2019-10-07 19:55:14', '10', 'Disco Duro', '', 'Inserción del Disco Duro con capacidad de 1 TB');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('17', '2019-10-07 19:55:28', '10', 'Disco Duro', '', 'Inserción del Disco Duro con capacidad de 2 TB');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('18', '2019-10-07 19:55:35', '10', 'Disco Duro', '', 'Actualización del Disco Duro con capacidad de  1 TB');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('19', '2019-10-07 19:55:44', '10', 'Disco Duro', '', 'Actualización del Disco Duro con capacidad de  500 GB');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('20', '2019-10-07 19:55:53', '10', 'Disco Duro', '', 'Actualización del Disco Duro con capacidad de  250 GB');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('21', '2019-10-07 19:56:10', '10', 'Antivirus', '', 'Inserción del antivirus WINDOWS DEFENDER');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('22', '2019-10-07 19:56:36', '10', 'Sistemas', '', 'Inserción del Sistema Operativo Windows 8');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('23', '2019-10-07 19:56:42', '10', 'Sistemas', '', 'Inserción del Sistema Operativo Windows 10');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('24', '2019-10-07 19:58:30', '10', 'Recurso de Red', '', 'Inserción del Recurso de Red Equipo de cómputo');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('25', '2019-10-07 19:58:45', '10', 'Recurso de Red', '', 'Inserción del Recurso de Red Terabyte');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('26', '2019-10-07 19:59:02', '10', 'Recurso de Red', '', 'Inserción del Recurso de Red Correo electrónico');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('27', '2019-10-07 19:59:28', '10', 'Recurso de Red', '', 'Actualización del Recurso de Red Usuario de equipo');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('28', '2019-10-07 19:59:56', '10', 'Recurso de Red', '', 'Actualización del Recurso de Red Contraseña del equipo');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('29', '2019-10-07 20:00:20', '10', 'Recurso de Red', '', 'Inserción del Recurso de Red Contraseña de correo');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('30', '2019-10-07 20:00:33', '10', 'Recurso de Red', '', 'Inserción del Recurso de Red Terabyte');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('31', '2019-10-07 20:01:28', '10', 'Modelo', '', 'Inserción de un nuevo modelo con el nombre Think Centre');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('32', '2019-10-07 20:02:37', '10', 'Categoria', '', 'Inserción de la Categoria Escritorio');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('33', '2019-10-07 20:04:30', '10', 'Categoria', '', 'Actualización de la Categoria Equipo de escritorio');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('34', '2019-10-07 20:04:45', '10', 'Categoria', '', 'Inserción de la Categoria Lap-Top');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('35', '2019-10-07 20:05:03', '10', 'Ip', '', 'Inserción de IP 172.17.124.1');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('36', '2019-10-07 20:09:56', '10', 'Ip', '', 'Actualización de IP 172.17.124.21');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('37', '2019-10-07 20:10:06', '10', 'Ip', '', 'Actualización de IP 172.17.124.22');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('38', '2019-10-07 20:10:15', '10', 'Ip', '', 'Actualización de IP 172.17.124.23');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('39', '2019-10-07 20:10:25', '10', 'Ip', '', 'Actualización de IP 172.17.124.24');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('40', '2019-10-07 20:39:34', '10', 'Modelo', '', 'Inserción de un nuevo modelo con el nombre Think Vision');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('41', '2019-10-07 20:46:57', '10', 'Proveedores', '', 'Inserción de nuevo Proveedor con NIT 2000');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('42', '2019-10-08 17:30:13', '10', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('43', '2019-10-08 18:04:07', '10', 'Usuarios', '', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('44', '2019-10-08 18:08:37', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('45', '2019-10-08 18:21:03', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('46', '2019-10-08 18:38:31', '1', 'Usuarios', '', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('47', '2019-10-08 18:40:07', '6', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('48', '2019-10-08 18:49:44', '6', 'Usuarios', '', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('49', '2019-10-08 18:49:48', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('50', '2019-10-08 20:32:09', '4', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('51', '2019-10-09 18:13:39', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('52', '2019-10-09 18:15:17', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('53', '2019-10-09 21:10:40', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('54', '2019-10-15 20:43:37', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('55', '2019-10-16 21:43:28', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('56', '2019-10-18 17:34:16', '1', 'Usuarios', '', 'Inicio de sesión');


#
# TABLE STRUCTURE FOR: memorias
#

DROP TABLE IF EXISTS `memorias`;

CREATE TABLE `memorias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `capacidad` varchar(250) NOT NULL,
  `fabricante_id` int(11) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `memorias` (`id`, `capacidad`, `fabricante_id`, `estado`) VALUES ('1', '4GB', '1', '1');
INSERT INTO `memorias` (`id`, `capacidad`, `fabricante_id`, `estado`) VALUES ('2', '8GB', '1', '1');
INSERT INTO `memorias` (`id`, `capacidad`, `fabricante_id`, `estado`) VALUES ('3', '12GB', '1', '1');


#
# TABLE STRUCTURE FOR: monitores
#

DROP TABLE IF EXISTS `monitores`;

CREATE TABLE `monitores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(11) NOT NULL,
  `tamaño` varchar(100) NOT NULL,
  `proveedor_id` int(11) NOT NULL,
  `finca_id` int(11) NOT NULL,
  `area_id` int(11) NOT NULL,
  `contacto` varchar(250) NOT NULL,
  `fabricante_id` int(11) NOT NULL,
  `serial_fabricante` varchar(100) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `bitacora` text NOT NULL,
  `estado` tinyint(1) NOT NULL,
  `ultimo_mante` text DEFAULT NULL,
  `fecregistro` datetime NOT NULL,
  `usuario_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=148 DEFAULT CHARSET=latin1;

INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('1', 'V5R05289', '16 pulgadas', '2', '2', '9', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('2', 'V5R05356', '16 pulgadas', '2', '2', '16', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('3', 'V5R04635', '16 pulgadas', '2', '2', '9', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('4', 'V5R04623', '16 pulgadas', '2', '2', '9', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('5', 'V5R04632', '16 pulgadas', '2', '2', '6', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('6', 'V5R04619', '16 pulgadas', '2', '2', '5', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('7', 'V5R04627', '16 pulgadas', '2', '2', '16', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('8', 'V5R04630', '16 pulgadas', '2', '2', '8', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('9', 'V5R04620', '16 pulgadas', '2', '2', '16', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('10', 'V5R05280', '16 pulgadas', '2', '2', '1', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('11', 'V5R05277', '16 pulgadas', '2', '2', '5', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('12', 'V5R05274', '16 pulgadas', '2', '2', '16', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('13', 'V5R05273', '16 pulgadas', '2', '2', '5', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('14', 'V5R05313', '16 pulgadas', '2', '2', '5', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('15', 'V5R05310', '16 pulgadas', '2', '2', '5', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('16', 'V5R05307', '16 pulgadas', '2', '2', '5', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('17', 'V5R05361', '16 pulgadas', '2', '2', '16', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('18', 'V5R05283', '16 pulgadas', '2', '2', '16', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('19', 'V5R05461', '16 pulgadas', '2', '2', '5', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('20', 'V5R05286', '16 pulgadas', '2', '2', '5', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('21', 'V5R05341', '16 pulgadas', '2', '2', '5', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('22', 'V5R05344', '16 pulgadas', '2', '2', '5', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('23', 'V5R05346', '16 pulgadas', '2', '2', '5', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('24', 'V5R05323', '16 pulgadas', '2', '2', '5', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('25', 'V5R05326', '16 pulgadas', '2', '2', '5', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('26', 'V5R05335', '16 pulgadas', '2', '2', '5', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('27', 'V5R05338', '16 pulgadas', '2', '2', '5', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('28', 'V5R05351', '16 pulgadas', '2', '2', '16', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('29', 'V5R04634', '16 pulgadas', '2', '2', '1', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('30', 'V5R02969', '16 pulgadas', '2', '2', '1', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('31', 'V5R02971', '16 pulgadas', '2', '2', '1', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('32', 'V5R02967', '16 pulgadas', '2', '2', '1', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('33', 'V5R02968', '16 pulgadas', '2', '2', '1', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('34', 'V5R04638', '16 pulgadas', '2', '2', '1', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('35', 'V5R04624', '16 pulgadas', '2', '2', '1', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('36', 'V5R05354', '16 pulgadas', '2', '2', '1', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('37', 'V5R05314', '16 pulgadas', '2', '2', '1', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('38', 'V5R05304', '16 pulgadas', '2', '2', '1', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('39', 'V5R04639', '16 pulgadas', '2', '2', '4', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('40', 'V5R05281', '16 pulgadas', '2', '2', '4', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('41', 'V5R05284', '16 pulgadas', '2', '2', '4', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('42', 'V5R05287', '16 pulgadas', '2', '2', '4', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('43', 'V5R05290', '16 pulgadas', '2', '2', '5', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('44', 'V5R05293', '16 pulgadas', '2', '2', '6', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('45', 'V5R05296', '16 pulgadas', '2', '2', '16', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('46', 'V5R05299', '16 pulgadas', '2', '2', '16', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('47', 'V5R05332', '16 pulgadas', '2', '2', '16', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('48', 'V5R05329', '16 pulgadas', '2', '2', '5', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('49', 'V5R05320', '16 pulgadas', '2', '2', '5', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('50', 'V5R05317', '16 pulgadas', '2', '2', '5', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('51', 'V5R05358', '16 pulgadas', '2', '2', '2', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('52', 'V5R05945', '16 pulgadas', '2', '2', '16', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('53', 'V5R05946', '16 pulgadas', '2', '2', '4', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('54', 'V5R05959', '16 pulgadas', '2', '2', '2', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('55', 'V5R05947', '16 pulgadas', '2', '2', '2', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('56', 'V5R06632', '16 pulgadas', '2', '2', '2', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('57', 'V5R05976', '16 pulgadas', '2', '2', '2', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('58', 'V5R05978', '16 pulgadas', '2', '2', '2', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('59', 'V5R05977', '16 pulgadas', '2', '2', '2', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('60', 'V5R06000', '16 pulgadas', '2', '2', '2', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('61', 'V5R05999', '16 pulgadas', '2', '2', '2', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('62', 'V5R06002', '16 pulgadas', '2', '2', '2', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('63', 'V5R06001', '16 pulgadas', '2', '2', '2', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('64', 'V5R06716', '16 pulgadas', '2', '2', '2', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('65', 'V5R06809', '16 pulgadas', '2', '2', '2', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('66', 'V5R06024', '16 pulgadas', '2', '2', '2', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('67', 'V5R06328', '16 pulgadas', '2', '2', '9', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('68', 'V5R05939', '16 pulgadas', '2', '2', '2', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('69', 'V5R05940', '16 pulgadas', '2', '2', '2', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('70', 'V5R05944', '16 pulgadas', '2', '2', '2', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('71', 'V5R05943', '16 pulgadas', '2', '2', '16', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('72', 'V5R06652', '16 pulgadas', '2', '2', '2', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('73', 'V5R05973', '16 pulgadas', '2', '2', '2', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('74', 'V5R05974', '16 pulgadas', '2', '2', '2', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('75', 'V5R05975', '16 pulgadas', '2', '2', '16', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('76', 'V5R05995', '16 pulgadas', '2', '2', '2', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('77', 'V5R06013', '16 pulgadas', '2', '2', '2', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('78', 'V5R05998', '16 pulgadas', '2', '2', '2', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('79', 'V5R05997', '16 pulgadas', '2', '2', '2', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('80', 'V5R06011', '16 pulgadas', '2', '2', '2', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('81', 'V5R06010', '16 pulgadas', '2', '2', '2', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('82', 'V5R06855', '16 pulgadas', '2', '2', '8', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('83', 'V5R06845', '16 pulgadas', '2', '2', '16', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('84', 'V5R05948', '16 pulgadas', '2', '2', '6', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('85', 'V5R05938', '16 pulgadas', '2', '2', '6', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('86', 'V5R05942', '16 pulgadas', '2', '2', '6', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('87', 'V5R05941', '16 pulgadas', '2', '2', '6', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('88', 'V5R06604', '16 pulgadas', '2', '2', '6', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('89', 'V5R06937', '16 pulgadas', '2', '2', '8', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('90', 'V5R05981', '16 pulgadas', '2', '2', '8', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('91', 'V5R06642', '16 pulgadas', '2', '2', '8', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('92', 'V5R05991', '16 pulgadas', '2', '2', '8', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('93', 'V5R05992', '16 pulgadas', '2', '2', '8', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('94', 'V5R05993', '16 pulgadas', '2', '2', '8', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('95', 'V5R05994', '16 pulgadas', '2', '2', '8', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('96', 'V5R06007', '16 pulgadas', '2', '2', '8', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('97', 'V5R06008', '16 pulgadas', '2', '2', '8', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('98', 'V5R06699', '16 pulgadas', '2', '2', '8', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('99', 'V5R06680', '16 pulgadas', '2', '2', '8', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('100', 'V5R05957', '16 pulgadas', '2', '2', '8', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('101', 'V5R05958', '16 pulgadas', '2', '2', '8', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('102', 'V5R05970', '16 pulgadas', '2', '2', '8', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('103', 'V5R05960', '16 pulgadas', '2', '2', '2', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('104', 'V5R06009', '16 pulgadas', '2', '2', '3', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('105', 'V5R05969', '16 pulgadas', '2', '2', '16', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('106', 'V5R06036', '16 pulgadas', '2', '2', '6', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('107', 'V5R05971', '16 pulgadas', '2', '2', '2', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('108', 'V5R05987', '16 pulgadas', '2', '2', '3', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('109', 'V5R05988', '16 pulgadas', '2', '2', '16', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('110', 'V5R05989', '16 pulgadas', '2', '2', '3', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('111', 'V5R05990', '16 pulgadas', '2', '2', '7', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('112', 'V5R06912', '16 pulgadas', '2', '2', '4', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('113', 'V5R06914', '16 pulgadas', '2', '2', '7', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('114', 'V5R06931', '16 pulgadas', '2', '2', '7', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('115', 'V5R06938', '16 pulgadas', '2', '2', '4', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('116', 'V5R05953', '16 pulgadas', '2', '2', '6', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('117', 'V5R05954', '16 pulgadas', '2', '2', '16', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('118', 'V5R05955', '16 pulgadas', '2', '2', '2', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('119', 'V5R05956', '16 pulgadas', '2', '2', '4', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('120', 'V5R05966', '16 pulgadas', '2', '2', '4', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('121', 'V5R05967', '16 pulgadas', '2', '2', '4', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('122', 'V5R05968', '16 pulgadas', '2', '2', '2', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('123', 'V5R05983', '16 pulgadas', '2', '2', '4', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('124', 'V5R05984', '16 pulgadas', '2', '2', '4', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('125', 'V5R05996', '16 pulgadas', '2', '2', '4', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('126', 'V5R05986', '16 pulgadas', '2', '2', '4', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('127', 'V5R06923', '16 pulgadas', '2', '2', '1', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('128', 'V5R06915', '16 pulgadas', '2', '2', '9', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('129', 'V5R06916', '16 pulgadas', '2', '2', '4', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('130', 'V5R06921', '16 pulgadas', '2', '2', '4', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('131', 'V5R05949', '16 pulgadas', '2', '2', '4', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('132', 'V5R05950', '16 pulgadas', '2', '2', '9', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('133', 'V5R05951', '16 pulgadas', '2', '2', '5', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('134', 'V5R05952', '16 pulgadas', '2', '2', '2', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('135', 'V5R05962', '16 pulgadas', '2', '2', '2', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('136', 'V5R05963', '16 pulgadas', '2', '2', '5', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('137', 'V5R06799', '16 pulgadas', '2', '2', '5', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('138', 'V5R06836', '16 pulgadas', '2', '2', '5', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('139', 'V5R05979', '16 pulgadas', '2', '2', '2', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('140', 'V5R05980', '16 pulgadas', '2', '2', '1', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('141', 'V5R05985', '16 pulgadas', '2', '2', '4', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('142', 'V5R05982', '16 pulgadas', '2', '2', '4', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('143', 'V5R06003', '16 pulgadas', '2', '2', '4', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('144', 'V5R06004', '16 pulgadas', '2', '2', '4', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('145', 'V5R06005', '16 pulgadas', '2', '2', '2', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('146', 'V5R06006', '16 pulgadas', '2', '2', '4', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('147', 'V5R05965', '16 pulgadas', '2', '2', '4', 'FONCA', '1', '00PC197', 'FONCA', 'OK', '1', NULL, '2019-10-07 00:00:00', '3');


#
# TABLE STRUCTURE FOR: monitores_mantenimientos
#

DROP TABLE IF EXISTS `monitores_mantenimientos`;

CREATE TABLE `monitores_mantenimientos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `monitor_id` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `tecnico` varchar(250) NOT NULL,
  `descripcion` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: nobreak
#

DROP TABLE IF EXISTS `nobreak`;

CREATE TABLE `nobreak` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `no_serie` int(11) NOT NULL,
  `modelo` varchar(100) NOT NULL,
  `id_area` int(11) NOT NULL,
  `descripcion` text NOT NULL,
  `estado` tinyint(1) NOT NULL,
  `fecregistro` date NOT NULL,
  `usuario_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: office
#

DROP TABLE IF EXISTS `office`;

CREATE TABLE `office` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `office` (`id`, `nombre`, `estado`) VALUES ('1', 'Office 2010', '1');
INSERT INTO `office` (`id`, `nombre`, `estado`) VALUES ('2', 'Office 2013', '1');
INSERT INTO `office` (`id`, `nombre`, `estado`) VALUES ('3', 'Office 2016', '1');


#
# TABLE STRUCTURE FOR: presentaciones
#

DROP TABLE IF EXISTS `presentaciones`;

CREATE TABLE `presentaciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(250) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `presentaciones` (`id`, `nombre`, `estado`) VALUES ('1', 'Think Centre', '1');
INSERT INTO `presentaciones` (`id`, `nombre`, `estado`) VALUES ('2', 'Think Vision', '1');


#
# TABLE STRUCTURE FOR: procesadores
#

DROP TABLE IF EXISTS `procesadores`;

CREATE TABLE `procesadores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `referencia` varchar(250) NOT NULL,
  `velocidad` varchar(250) NOT NULL,
  `fabricante_id` int(11) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `procesadores` (`id`, `referencia`, `velocidad`, `fabricante_id`, `estado`) VALUES ('1', 'Intel Pentium G4560', '3.50 GHZ', '1', '1');


#
# TABLE STRUCTURE FOR: propietarios
#

DROP TABLE IF EXISTS `propietarios`;

CREATE TABLE `propietarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(250) NOT NULL,
  `apMat` varchar(250) NOT NULL,
  `apPat` varchar(250) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=148 DEFAULT CHARSET=latin1;

INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('1', 'DENISE MAGDALENA', 'TRUJILLO', 'ULLOA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('2', 'SONIA', 'CORDERO', 'ALTAMIRANO', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('3', 'ANA BERTHA', 'MARTíNEZ', 'PEREZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('4', 'SAúL MICHEL', 'GARCíA', 'GARNICA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('5', 'MARIA DEL PILAR JAZMíN', 'JIMéNEZ ', 'MORENO', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('6', 'ROSARIO ', 'PERALTA', 'VALLE', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('7', 'PAULINA', 'RAMíREZ', 'ESTRELLO', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('8', 'JULIO', 'AGUILAR', 'ALFARO', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('9', 'FABIOLA', 'SáNCHEZ', 'RODRíGUEZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('10', 'DAMIáN ', 'MORALES ', 'CAMPOS', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('11', 'LUIS DAVID ', 'CáRDENAS ', 'LUNA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('12', 'JACOBO ', 'MORALES', 'LOAIZA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('13', 'MARIA DE JESúS', 'MAGAñA', 'GONZáLEZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('14', 'CAROLINA', 'RAMíREZ', 'ESTRADA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('15', 'MIRIAM GUADALUPE', 'OCAMPO', 'EUAN', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('16', 'SERGIO DANIEL ', 'LIMóN ', 'GONZáLEZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('17', 'ITZEL YASANET', 'ESCOTO', 'UGALDE', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('18', 'JAVIER', 'NáJERA', 'FRANCO', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('19', 'MARíA ELENA', 'GONZáLEZ', 'PEDRAZA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('20', 'LUIS  ', 'ESTRADA', 'RAMIREZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('21', 'LUIS ENRIQUE', 'RAMOS', 'PADILLA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('22', 'SAITIELA MONSERRAT ', 'RUíZ', 'LóPEZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('23', 'ALEJANDRA', 'FLORES', 'BRAVO', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('24', 'VANIA', 'ESCORCIA', 'LóPEZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('25', 'ERICK', 'PéREZ', 'VELASCO', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('26', 'GERARDO ', 'GARCíA', 'LóPEZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('27', 'LUIS ARTURO', 'LERATE', 'AGUILAR', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('28', 'ADRIANA', 'CAMARENA', 'DE OBESO', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('29', 'BEATRIZ ELENA', 'SALAS', 'PLASCENCIA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('30', 'MAGDA ', 'ORTIZ ', 'AYALA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('31', 'LAURA ELIZABETH', 'CORTéS', 'GóMEZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('32', 'SINUé', 'HUERTA', 'JUVERA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('33', 'RAFAEL', 'BECERRA', 'LEAL', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('34', 'MARCELA ISABEL', 'CABRERA', 'OSORIO', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('35', 'MAGDALENA ', 'ANDRADE', 'BRISEñO', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('36', 'CARLA LUCIA', 'FUENTES', 'LARRAñAGA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('37', 'ISAí', 'LóPEZ', 'LóPEZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('38', 'RAFAEL', 'MONDRAGON ', 'LEAL', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('39', 'VICTOR ADRIAN', 'MARTíNEZ', 'PACHECO', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('40', 'ALEJANDRO', 'CAMARENA', 'DOMINGUEZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('41', 'NANCY VIRIDIANA', 'GóMEZ', 'GARDUñO', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('42', 'MORONI USVALDO ', 'TORRES ', 'GUILLéN', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('43', 'MARIA DEL CARMEN', 'AGUIRRE', 'DELGADO', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('44', 'LILIANA KAREN', 'DE LA MORA', 'SOLíS', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('45', 'MARINA', 'GORDILLO', 'PACHECO', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('46', 'ROSARIO', 'GARDUñO', 'HERNáNDEZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('47', 'MóNICA PILAR ', 'PEREDO', 'PéREZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('48', 'JUAN CARLOS ', 'LUCAS', 'ARIAS', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('49', 'GUSTAVO', 'ROMERO', 'CORREDOR', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('50', 'ALEXIS CALEB', 'GRAUPNER', 'MARTíN DEL CAMPO', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('51', 'CARLOS ', 'CORREA', 'MORALES', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('52', 'MARIA TERESA', 'MARTíNEZ', 'RODRIGUEZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('53', 'JORGE ALEJANDRO ', 'GARCíA ', 'GUERRERO', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('54', 'SARA', 'NARVáEZ', 'GARCíA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('55', 'ROCíO', 'RAMóN', 'GARCíA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('56', 'BARBARA', 'UGALDE', 'CORONA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('57', 'IVONNE', 'BERNAL', 'ORTIZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('58', 'GERARDO ', 'GONZáLEZ', 'CERóN', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('59', 'URY ESTEBAN', 'GARCIA', 'BERNAL', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('60', 'LUIS ANTONIO', 'GONZáLEZ ', 'AGUILAR', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('61', 'CHRISTOPHER', 'CARRILLO', 'BARRIGA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('62', 'MARGARITA', 'AGUILAR', 'MARTíNEZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('63', 'OLGA ', 'OSORIO', 'OSORIO', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('64', 'MARIA ENRIQUETA', 'SIERRA', 'LAGUNA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('65', 'MARIA GUADALUPE', 'LOZA', ' GONZáLEZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('66', 'NéSTOR DANIEL ', 'RIVAS ', 'SERRALDE', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('67', 'ISMAEL ', 'REYES', 'BLANCAS', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('68', 'JOSE NEFTALI', 'REYES', 'BLANCAS', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('69', 'MARCOS ', 'LURIAS', 'ALOR', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('70', 'JOSé LUIS', 'ARELLANO', 'HERNáNDEZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('71', 'YARET ALEXIS', 'GONZáLEZ', 'VILLA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('72', 'JUAN ', 'CRUZ', 'GARCíA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('73', 'MIGUEL ÁNGEL ', 'RíOS ', 'CRUZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('74', 'ANTONIA ', 'HEREDIA', ' VELAZQUEZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('75', 'MARíA DEL CARMéN', 'HERNANDEZ', 'MORENO', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('76', 'HAYDEE RUBI ', 'AGUILAR ', 'RODRIGUEZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('77', 'ROSARIO ', 'JIMéNEZ', 'DEL VALLE', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('78', 'LEONOR ', 'GóMEZ', 'GARCíA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('79', 'ARTURO CéSAR', 'MADRID', 'MORALES', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('80', 'GABRIELA', 'ROQUE DEPLANCHE', 'GALVáN', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('81', 'FERNANDO', 'CORREA', 'PéREZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('82', 'JULIETA IZCARULLI ', 'MARTINEZ ', 'LOPEZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('83', 'SERGIO', 'ORTIZ', 'ROMERO', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('84', 'BLANCA LORENA', 'OLVERA ', 'GARCIA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('85', 'EDWIN', 'RUBIO', 'CARDOSO', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('86', 'GUSTAVO ALEJANDRO', 'ORTEGA', 'MENDIOLA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('87', 'MARíA DE JESúS', 'PALAFOX ', 'MARTíNEZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('88', 'REYNALDO ', 'MALDONADO', 'VELáSQUEZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('89', 'RAQUEL', 'LóPEZ', 'SOLEDAD', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('90', 'YULIANA', 'MACIEL', 'AMEZCUA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('91', 'JORGE', 'JUáREZ', 'GUTIéRREZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('92', 'JOSé MARCOS ', 'VARGAS', 'RODRíGUEZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('93', 'ILSE LIZETH', 'PINEDA', 'ESPINOZA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('94', 'CLAUDIA NOEMI ', 'ROSAS ', 'TRUJILLO', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('95', 'ANGéLICA', 'LóPEZ', 'SáNCHEZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('96', 'ANDREA', 'VEGA', 'GóMEZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('97', 'DIANA GRACIELA ', 'CANTú ', 'CERVANTES', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('98', 'PEDRO', 'GUERRA ', 'GUAJARDO', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('99', 'EDITH ', 'CAZARES ', 'CáBRERA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('100', 'PILAR ELENA', 'VARGAS', 'RODRíGUEZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('101', 'GERMáN', 'VILLEGAS', 'ARELLANO', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('102', 'YOLANDA JOSEFINA', 'GARCíA', 'MARTíNEZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('103', 'ANASTASIO', 'FLORES', 'ORTEGA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('104', 'HILDA ', 'CUEVAS', 'OLIVO', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('105', 'BETHSABé DAFNE', 'GUZMáN', 'TREJO', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('106', 'KARLA', 'ECHAVARRíA', 'MUñIZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('107', 'DIEGO ISAAC', 'GONZáLEZ', 'GóMEZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('108', 'LOURDES', 'VICENTE', 'VELáSQUEZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('109', 'ELIZABETH', 'DOMINGUEZ', 'CERVANTES', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('110', 'ALICIA', 'MARTíNEZ', 'GóMEZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('111', 'CATALINA', 'MUñOZ', 'TELLEZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('112', 'ILIANA ARLETTE', 'ROBLEDO', 'POLA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('113', 'LORENA ARTEMISA', 'ORTEGA', 'ORTEGA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('114', 'BRENDA', 'SALAZAR', 'GONZáLEZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('115', 'GUILLERMO ALí ', 'MORAN', 'HUERTA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('116', 'GUILLERMO ALí ', 'MORAN', 'HUERTA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('117', 'GUILLERMO ALí ', 'MORAN', 'HUERTA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('118', 'GUILLERMO ALí ', 'MORAN', 'HUERTA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('119', 'GUILLERMO ALí ', 'MORAN', 'HUERTA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('120', 'RAúL ', 'CRUZ', 'FONSECA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('121', 'RAúL ', 'CRUZ', 'FONSECA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('122', 'RAúL ', 'CRUZ', 'FONSECA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('123', 'RAúL ', 'CRUZ', 'FONSECA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('124', 'ALEJANDRO', 'CAMARENA', 'DOMINGUEZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('125', 'MORONI USVALDO ', 'TORRES ', 'GUILLéN', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('126', 'GUILLERMO ALí ', 'MORAN', 'HUERTA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('127', 'GUILLERMO ALí ', 'MORAN', 'HUERTA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('128', 'RAúL ', 'CRUZ', 'FONSECA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('129', 'FERNANDO ALBERTO', 'HERNANDEZ', 'ELIZARRARAS', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('130', 'RODRIGO ISRAEL', 'PéREZ', 'GONZALEZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('131', 'MARTíN', 'ZúñIGA', 'MALDONADO', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('132', 'ANGéLICA MOYFA', 'GARCíA', 'GARCíA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('133', 'SAMUEL ', 'MENDOZA', 'FUENTES', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('134', 'ANA YEDID', 'GARCIA', 'VERGARA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('135', 'JUDITH ', 'GARDUñO', 'DE LA CRUZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('136', 'VANIA', 'SAUER', 'VERA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('137', 'ALMA MIRIAM ', 'ANDRADE ', 'DE LA CRUZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('138', 'Eduardo', 'Rezèndiz', '', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('139', 'JOSé FRANCISCO', 'ALONSO', 'GóMEZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('140', 'MóNICA ', 'BOLAñOS', 'PINEDA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('141', 'IVONNE ', 'PéREZ', 'ESQUIVEL', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('142', 'ANTONIO VALENTíN', 'DOSTA', 'GARCíA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('143', 'FERNANDO ALBERTO', 'HERNANDEZ', 'ELIZARRARAS', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('144', 'RODRIGO ISRAEL', 'PéREZ', 'GONZALEZ', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('145', 'ANTONIO VALENTíN', 'DOSTA', 'GARCíA', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('146', 'JOSUE', 'GALINDO', 'TORRES', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('147', 'GEORGINA CONSUELO', 'VELASCO', 'SEGURA', '1');


#
# TABLE STRUCTURE FOR: proveedores
#

DROP TABLE IF EXISTS `proveedores`;

CREATE TABLE `proveedores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(250) NOT NULL,
  `nit` varchar(100) NOT NULL,
  `direccion` varchar(250) NOT NULL,
  `correo` varchar(250) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `proveedores` (`id`, `nombre`, `nit`, `direccion`, `correo`, `estado`) VALUES ('1', 'Intel', '2000', 'Torre Esmeralda II, Perif. Blvd. Manuel Ávila Camacho 36, Lomas de Chapultepec, 11000 Ciudad de México, CDMX', '@IntelSupport', '1');
INSERT INTO `proveedores` (`id`, `nombre`, `nit`, `direccion`, `correo`, `estado`) VALUES ('2', 'Lenovo', '2000', 'Paseo de Los Tamarindos 400 A Col, Bosques de las Lomas, 05120 Ciudad de México', '@LenovoLatam', '1');


#
# TABLE STRUCTURE FOR: proyectores
#

DROP TABLE IF EXISTS `proyectores`;

CREATE TABLE `proyectores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` int(11) NOT NULL,
  `fabricante_id` int(11) NOT NULL,
  `modelo` varchar(100) NOT NULL,
  `descripcion` text NOT NULL,
  `estado` tinyint(1) NOT NULL,
  `ultimo_mante` date DEFAULT NULL,
  `fecregistro` datetime NOT NULL,
  `usuario_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: proyectores_mantenimientos
#

DROP TABLE IF EXISTS `proyectores_mantenimientos`;

CREATE TABLE `proyectores_mantenimientos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proyector_id` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `tecnico` date NOT NULL,
  `descripcion` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: recursored
#

DROP TABLE IF EXISTS `recursored`;

CREATE TABLE `recursored` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(100) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `recursored` (`id`, `descripcion`, `estado`) VALUES ('1', 'Usuario de equipo', '1');
INSERT INTO `recursored` (`id`, `descripcion`, `estado`) VALUES ('2', 'Contraseña del equipo', '1');
INSERT INTO `recursored` (`id`, `descripcion`, `estado`) VALUES ('3', 'Correo electrónico', '1');
INSERT INTO `recursored` (`id`, `descripcion`, `estado`) VALUES ('4', 'Contraseña de correo', '1');
INSERT INTO `recursored` (`id`, `descripcion`, `estado`) VALUES ('5', 'Terabyte', '1');


#
# TABLE STRUCTURE FOR: roles
#

DROP TABLE IF EXISTS `roles`;

CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) NOT NULL,
  `descripcion` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `roles` (`id`, `nombre`, `descripcion`) VALUES ('1', 'Administrador', 'Tiene control total del sistema, además de que puede hacer un respaldo de la base de datos y ver lo que otros usuarios hacen en él');
INSERT INTO `roles` (`id`, `nombre`, `descripcion`) VALUES ('2', 'Técnico', 'Puede añadir, editar, ver y hacer los reportes de los registros y módulos del sistema ');
INSERT INTO `roles` (`id`, `nombre`, `descripcion`) VALUES ('3', 'Reportes', 'Solo puede hacer los reportes de los módulos ya creados ');
INSERT INTO `roles` (`id`, `nombre`, `descripcion`) VALUES ('4', 'Usuario', 'Un perfil meramente informativo para los usuarios donde podrán ver su información');


#
# TABLE STRUCTURE FOR: sistemas
#

DROP TABLE IF EXISTS `sistemas`;

CREATE TABLE `sistemas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(100) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `sistemas` (`id`, `descripcion`, `estado`) VALUES ('1', 'Windows 8', '1');
INSERT INTO `sistemas` (`id`, `descripcion`, `estado`) VALUES ('2', 'Windows 10', '1');


#
# TABLE STRUCTURE FOR: telefonos
#

DROP TABLE IF EXISTS `telefonos`;

CREATE TABLE `telefonos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `no_ext` int(11) NOT NULL,
  `no_serie` int(11) NOT NULL,
  `usuario_telefono` varchar(250) NOT NULL,
  `id_ip` int(11) NOT NULL,
  `modelo` varchar(100) NOT NULL,
  `id_area` int(11) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  `ultimo_mante` date DEFAULT NULL,
  `fecregistro` datetime NOT NULL,
  `usuario_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: telefonos_mantenimientos
#

DROP TABLE IF EXISTS `telefonos_mantenimientos`;

CREATE TABLE `telefonos_mantenimientos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tablet_id` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `tecnico` varchar(250) NOT NULL,
  `descripcion` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: usuarios
#

DROP TABLE IF EXISTS `usuarios`;

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombres` varchar(200) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(100) NOT NULL,
  `cedula` int(11) NOT NULL,
  `sexo` varchar(100) NOT NULL,
  `rol_id` int(11) DEFAULT NULL,
  `estado` tinyint(1) NOT NULL,
  `imagen` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `usuarios` (`id`, `nombres`, `email`, `password`, `cedula`, `sexo`, `rol_id`, `estado`, `imagen`) VALUES ('1', 'Adolfo Silva', 'asilva', '7c4a8d09ca3762af61e59520943dc26494f8941b', '1000', 'M', '1', '1', 'imagen_masculino.jpg');
INSERT INTO `usuarios` (`id`, `nombres`, `email`, `password`, `cedula`, `sexo`, `rol_id`, `estado`, `imagen`) VALUES ('2', 'Fabiola Gúzman', 'fguzman', '11e776696e454cd696d135d9aa5de378cc1eb8da', '3000', 'M', '3', '1', 'imagen_masculino.jpg');
INSERT INTO `usuarios` (`id`, `nombres`, `email`, `password`, `cedula`, `sexo`, `rol_id`, `estado`, `imagen`) VALUES ('3', 'Víctor Martínez', 'vmartinez', '4f5e7f4f938760cd314293f888ae4288e6e3e6f8', '2000', 'M', '2', '1', 'imagen_masculino.jpg');
INSERT INTO `usuarios` (`id`, `nombres`, `email`, `password`, `cedula`, `sexo`, `rol_id`, `estado`, `imagen`) VALUES ('4', 'Raúl Fonseca', 'rfonseca', '7c4a8d09ca3762af61e59520943dc26494f8941b', '1001', 'M', '1', '1', 'imagen_masculino.jpg');
INSERT INTO `usuarios` (`id`, `nombres`, `email`, `password`, `cedula`, `sexo`, `rol_id`, `estado`, `imagen`) VALUES ('5', 'Adrián Manzano', 'amanzano', '7c4a8d09ca3762af61e59520943dc26494f8941b', '4000', 'M', '4', '1', 'imagen_masculino.jpg');
INSERT INTO `usuarios` (`id`, `nombres`, `email`, `password`, `cedula`, `sexo`, `rol_id`, `estado`, `imagen`) VALUES ('6', 'Alejandro Camarena', 'acamarena', '7c4a8d09ca3762af61e59520943dc26494f8941b', '2001', 'M', '2', '1', 'imagen_masculino.jpg');


