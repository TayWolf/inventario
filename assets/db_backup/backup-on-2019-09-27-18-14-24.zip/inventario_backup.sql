#
# TABLE STRUCTURE FOR: antivirus
#

DROP TABLE IF EXISTS `antivirus`;

CREATE TABLE `antivirus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(250) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `antivirus` (`id`, `descripcion`, `estado`) VALUES ('1', 'Nod 32', '1');
INSERT INTO `antivirus` (`id`, `descripcion`, `estado`) VALUES ('2', 'Avast 8', '1');
INSERT INTO `antivirus` (`id`, `descripcion`, `estado`) VALUES ('3', 'Karpesky 7', '0');
INSERT INTO `antivirus` (`id`, `descripcion`, `estado`) VALUES ('4', 'Prueba', '0');


#
# TABLE STRUCTURE FOR: areas
#

DROP TABLE IF EXISTS `areas`;

CREATE TABLE `areas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `areas` (`id`, `nombre`, `estado`) VALUES ('1', 'Recursos Humanos', '1');
INSERT INTO `areas` (`id`, `nombre`, `estado`) VALUES ('2', 'Contabilidad', '0');
INSERT INTO `areas` (`id`, `nombre`, `estado`) VALUES ('3', 'Samsung', '0');
INSERT INTO `areas` (`id`, `nombre`, `estado`) VALUES ('4', 'informatica', '1');


#
# TABLE STRUCTURE FOR: cargos
#

DROP TABLE IF EXISTS `cargos`;

CREATE TABLE `cargos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(250) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `cargos` (`id`, `descripcion`, `estado`) VALUES ('1', 'Jefe de Área', '1');
INSERT INTO `cargos` (`id`, `descripcion`, `estado`) VALUES ('2', 'Empleado', '1');
INSERT INTO `cargos` (`id`, `descripcion`, `estado`) VALUES ('3', 'Dirección', '1');


#
# TABLE STRUCTURE FOR: categoria
#

DROP TABLE IF EXISTS `categoria`;

CREATE TABLE `categoria` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(100) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `categoria` (`id`, `descripcion`, `estado`) VALUES ('1', 'Laptop', '1');
INSERT INTO `categoria` (`id`, `descripcion`, `estado`) VALUES ('2', 'Computadora de escritorio', '1');
INSERT INTO `categoria` (`id`, `descripcion`, `estado`) VALUES ('4', 'MAC EDIT', '1');


#
# TABLE STRUCTURE FOR: computadoras
#

DROP TABLE IF EXISTS `computadoras`;

CREATE TABLE `computadoras` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` int(11) NOT NULL,
  `monitor_id` int(11) NOT NULL,
  `presentacion_id` int(11) NOT NULL,
  `proveedor_id` int(11) NOT NULL,
  `finca_id` int(11) NOT NULL,
  `area_id` int(11) NOT NULL,
  `contacto` varchar(250) NOT NULL,
  `fabricante_id` int(11) NOT NULL,
  `procesador_id` int(11) NOT NULL,
  `ram_id` int(11) NOT NULL,
  `disco_id` int(11) NOT NULL,
  `so_id` int(11) NOT NULL,
  `serial_so` int(11) NOT NULL,
  `office_id` int(11) NOT NULL,
  `serial_office` int(11) NOT NULL,
  `antivirus_id` int(11) NOT NULL,
  `ip_id` int(4) NOT NULL,
  `mac` varchar(50) NOT NULL,
  `bitacora` text NOT NULL,
  `estado` tinyint(1) NOT NULL,
  `ultimo_mante` date DEFAULT NULL,
  `fecregistro` datetime NOT NULL,
  `usuario_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('1', '9121', '1', '1', '2', '1', '2', 'Jose Perez', '1', '1', '2', '1', '1', '1010212', '1', '11221', '2', '1', '12123121', 'Esta todo ok', '1', '2019-09-12', '2018-06-11 07:09:11', '1');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('2', '99112', '1', '2', '1', '1', '1', 'Maria Cortez', '2', '1', '1', '1', '2', '120011', '1', '101212', '2', '2', '12123121', 'esta funcionable', '1', '2018-06-11', '2018-06-11 04:21:16', '1');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('3', '991', '1', '2', '2', '1', '2', 'juan Cortez', '1', '1', '2', '1', '1', '121212', '1', '12131', '1', '3', '112-11111', 'Too esta funcionando', '1', '2018-06-13', '2018-06-12 10:00:00', '1');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('4', '12', '2', '1', '1', '1', '1', 'Carlos Gomez', '1', '1', '2', '1', '1', '121212', '1', '12121', '2', '192', '121-1212', 'Funcionando muy Bien', '1', NULL, '2018-06-24 17:04:29', '1');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('5', '12112', '1', '1', '1', '1', '2', 'Carlos Gomez', '1', '1', '1', '1', '2', '121212', '1', '131214', '1', '192', '121-1212', 'Funcionando muy Bien', '1', NULL, '2018-06-30 11:12:10', '1');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('6', '1212', '1', '1', '1', '1', '1', 'Carmen gonzales', '1', '1', '1', '1', '1', '12', '1', '1212', '1', '192', '1212-1212', 'Esta Funcionable', '1', NULL, '0000-00-00 00:00:00', '1');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('7', '1313', '1', '1', '1', '1', '1', 'Jose Martinez', '1', '1', '1', '1', '1', '11012', '1', '1212', '1', '192', '1212-1213', 'Fallo en el prendido', '1', NULL, '0000-00-00 00:00:00', '1');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('8', '1212', '1', '1', '1', '1', '1', 'Carmen gonzales', '1', '1', '1', '1', '1', '12', '1', '1212', '1', '192', '1212-1212', 'Esta Funcionable', '1', NULL, '0000-00-00 00:00:00', '1');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('9', '1313', '1', '1', '1', '1', '1', 'Jose Martinez', '1', '1', '1', '1', '1', '11012', '1', '1212', '1', '192', '1212-1213', 'Fallo en el prendido', '1', NULL, '0000-00-00 00:00:00', '1');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('10', '901125', '1', '1', '1', '1', '1', 'Carmen gonzales', '1', '1', '1', '1', '1', '12', '1', '1212', '1', '192', '1212-1212', 'Esta Funcionable', '0', NULL, '2019-09-12 19:13:56', '4');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('11', '900124', '1', '1', '1', '1', '1', 'Jose Martinez', '1', '1', '1', '1', '1', '11012', '1', '1212', '1', '192', '1212-1213', 'Fallo en el prendido', '1', NULL, '0000-00-00 00:00:00', '1');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('12', '89812', '1', '1', '1', '1', '1', 'Carmen gonzales', '1', '1', '1', '1', '1', '12', '1', '1212', '1', '192', '1212-1212', 'Esta Funcionable', '1', NULL, '0000-00-00 00:00:00', '1');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('13', '89123', '1', '1', '1', '1', '1', 'Jose Martinez', '1', '1', '1', '1', '1', '11012', '1', '1212', '1', '192', '1212-1213', 'Fallo en el prendido', '1', NULL, '0000-00-00 00:00:00', '1');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('14', '89812', '1', '1', '1', '1', '1', 'Carmen gonzales', '1', '1', '1', '1', '1', '12', '1', '1212', '1', '192', '1212-1212', 'Esta Funcionable', '1', NULL, '0000-00-00 00:00:00', '1');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('15', '89123', '1', '1', '1', '1', '1', 'Jose Martinez', '1', '1', '1', '1', '1', '11012', '1', '1212', '1', '192', '1212-1213', 'Fallo en el prendido', '1', NULL, '0000-00-00 00:00:00', '1');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('16', '89812', '1', '1', '1', '1', '1', 'Carmen gonzales', '1', '1', '1', '1', '1', '12', '1', '1212', '1', '192', '1212-1212', 'Esta Funcionable', '1', NULL, '0000-00-00 00:00:00', '1');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('17', '89123', '1', '1', '1', '1', '1', 'Jose Martinez', '1', '1', '1', '1', '1', '11012', '1', '1212', '1', '192', '1212-1213', 'Fallo en el prendido', '1', NULL, '0000-00-00 00:00:00', '1');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('18', '5675', '1', '1', '1', '1', '1', 'Carmen gonzales', '1', '1', '1', '1', '1', '12', '1', '1212', '1', '192', '1212-1212', 'Esta Funcionable', '1', NULL, '0000-00-00 00:00:00', '1');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('19', '6575', '1', '1', '1', '1', '1', 'Jose Martinez', '1', '1', '1', '1', '1', '11012', '1', '1212', '1', '192', '1212-1213', 'Fallo en el prendido', '1', NULL, '0000-00-00 00:00:00', '1');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('20', '5675', '1', '1', '1', '1', '1', 'Carmen gonzales', '1', '1', '1', '1', '1', '12', '1', '1212', '1', '192', '1212-1212', 'Esta Funcionable', '1', NULL, '0000-00-00 00:00:00', '1');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('21', '6575', '1', '1', '1', '1', '1', 'Jose Martinez', '1', '1', '1', '1', '1', '11012', '1', '1212', '1', '192', '1212-1213', 'Fallo en el prendido', '1', NULL, '0000-00-00 00:00:00', '1');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('22', '5675', '1', '1', '1', '1', '1', 'Carmen gonzales', '1', '1', '1', '1', '1', '12', '1', '1212', '1', '192', '1212-1212', 'Esta Funcionable', '1', NULL, '0000-00-00 00:00:00', '1');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('23', '6575', '1', '1', '1', '1', '1', 'Jose Martinez', '1', '1', '1', '1', '1', '11012', '1', '1212', '1', '192', '1212-1213', 'Fallo en el prendido', '1', NULL, '0000-00-00 00:00:00', '1');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('24', '435', '1', '1', '1', '1', '1', 'Carmen gonzales', '1', '1', '1', '1', '1', '12', '1', '1212', '1', '192', '1212-1212', 'Esta Funcionable', '1', NULL, '0000-00-00 00:00:00', '1');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('25', '121', '1', '1', '1', '1', '1', 'Jose Martinez', '1', '1', '1', '1', '1', '11012', '1', '1212', '1', '192', '1212-1213', 'Fallo en el prendido', '1', NULL, '0000-00-00 00:00:00', '1');
INSERT INTO `computadoras` (`id`, `codigo`, `monitor_id`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip_id`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('26', '46342341', '3', '2', '1', '1', '1', 'Raul', '1', '1', '1', '1', '2', '1242131', '1', '1234', '2', '2', '123:2314:1241', 'En buen estado', '0', NULL, '2019-09-26 20:40:29', '1');


#
# TABLE STRUCTURE FOR: computadoras_mantenimientos
#

DROP TABLE IF EXISTS `computadoras_mantenimientos`;

CREATE TABLE `computadoras_mantenimientos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `computadora_id` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `tecnico` varchar(250) NOT NULL,
  `descripcion` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `computadoras_mantenimientos` (`id`, `computadora_id`, `fecha`, `tecnico`, `descripcion`) VALUES ('1', '1', '2018-06-11', 'Jose Luis Fernandez', 'Cambio de pila');
INSERT INTO `computadoras_mantenimientos` (`id`, `computadora_id`, `fecha`, `tecnico`, `descripcion`) VALUES ('2', '1', '2018-06-11', 'Jhon Manrique', 'Cambio de Memoria');
INSERT INTO `computadoras_mantenimientos` (`id`, `computadora_id`, `fecha`, `tecnico`, `descripcion`) VALUES ('3', '2', '2018-06-11', 'Jose Luis Fernandez', 'Cambio de Respuesto');
INSERT INTO `computadoras_mantenimientos` (`id`, `computadora_id`, `fecha`, `tecnico`, `descripcion`) VALUES ('4', '3', '2018-06-13', 'Jose Martinez', 'Limpieza interna');
INSERT INTO `computadoras_mantenimientos` (`id`, `computadora_id`, `fecha`, `tecnico`, `descripcion`) VALUES ('5', '1', '2019-09-12', 'Victor', 'No prende');


#
# TABLE STRUCTURE FOR: discos
#

DROP TABLE IF EXISTS `discos`;

CREATE TABLE `discos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `capacidad` varchar(250) NOT NULL,
  `fabricante_id` int(11) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `discos` (`id`, `capacidad`, `fabricante_id`, `estado`) VALUES ('1', '1024 mb', '1', '1');


#
# TABLE STRUCTURE FOR: elemento
#

DROP TABLE IF EXISTS `elemento`;

CREATE TABLE `elemento` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nit` int(11) NOT NULL,
  `nombre` varchar(250) NOT NULL,
  `direccion` varchar(250) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `descripcion` text NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `elemento` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('1', '10012', 'Propio', 'FONCA', '053464642', 'Equipo propio de la empresa', '1');
INSERT INTO `elemento` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('2', '1003', 'Arrendado', 'LENOVO', '88749201', 'Equipo proporcionado por el gobierno', '1');


#
# TABLE STRUCTURE FOR: fabricantes
#

DROP TABLE IF EXISTS `fabricantes`;

CREATE TABLE `fabricantes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(250) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `fabricantes` (`id`, `nombre`, `estado`) VALUES ('1', 'Chipset ', '1');
INSERT INTO `fabricantes` (`id`, `nombre`, `estado`) VALUES ('2', 'Intel', '1');


#
# TABLE STRUCTURE FOR: impresoras
#

DROP TABLE IF EXISTS `impresoras`;

CREATE TABLE `impresoras` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proveedor_id` int(11) NOT NULL,
  `finca_id` int(11) NOT NULL,
  `area_id` int(11) NOT NULL,
  `contacto` varchar(150) NOT NULL,
  `fabricante_id` int(11) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `serial_fabricante` int(11) NOT NULL,
  `bitacora` text NOT NULL,
  `codigo` int(11) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  `ultimo_mante` date DEFAULT NULL,
  `fecregistro` datetime NOT NULL,
  `usuario_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `impresoras` (`id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `referencia`, `serial_fabricante`, `bitacora`, `codigo`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('1', '1', '1', '2', 'Jose Perez', '1', 'refencia 01', '12129991', 'Esta todo bueno', '100143', '1', '0000-00-00', '2018-06-10 01:15:08', '1');
INSERT INTO `impresoras` (`id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `referencia`, `serial_fabricante`, `bitacora`, `codigo`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('2', '2', '1', '1', 'Jose Perez', '1', 'refencia 01', '12129992', 'equipo funcionable', '100143', '1', '0000-00-00', '2018-06-10 07:22:40', '1');
INSERT INTO `impresoras` (`id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `referencia`, `serial_fabricante`, `bitacora`, `codigo`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('3', '1', '1', '2', 'Jose Perez', '2', 'referencia de la impresora 01', '11201212', 'esta funcionable', '10012', '1', '2018-06-11', '2018-06-11 01:06:06', '1');
INSERT INTO `impresoras` (`id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `referencia`, `serial_fabricante`, `bitacora`, `codigo`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('4', '1', '1', '1', 'Julio Quintero', '1', 'referencia de la impresora', '121212', 'Esta funcionable', '1212', '1', NULL, '0000-00-00 00:00:00', '1');
INSERT INTO `impresoras` (`id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `referencia`, `serial_fabricante`, `bitacora`, `codigo`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('5', '1', '1', '1', 'Julio Gomez', '1', 'referencia de la impresora', '121212', 'Esta funcionable', '1231', '1', NULL, '0000-00-00 00:00:00', '1');


#
# TABLE STRUCTURE FOR: impresoras_mantenimientos
#

DROP TABLE IF EXISTS `impresoras_mantenimientos`;

CREATE TABLE `impresoras_mantenimientos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `impresora_id` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `tecnico` varchar(250) NOT NULL,
  `descripcion` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `impresoras_mantenimientos` (`id`, `impresora_id`, `fecha`, `tecnico`, `descripcion`) VALUES ('1', '3', '2018-06-11', 'Jhon Manrique', 'Cambio de Cartuchos');


#
# TABLE STRUCTURE FOR: ip
#

DROP TABLE IF EXISTS `ip`;

CREATE TABLE `ip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(250) NOT NULL,
  `id_codigo` int(11) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('1', '172.17.124.174', '1', '1');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('2', '172.17.124.172', '3', '1');
INSERT INTO `ip` (`id`, `descripcion`, `id_codigo`, `estado`) VALUES ('3', '172.17.124.154', '2', '0');


#
# TABLE STRUCTURE FOR: lectores
#

DROP TABLE IF EXISTS `lectores`;

CREATE TABLE `lectores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` int(11) NOT NULL,
  `fabricante_id` int(11) NOT NULL,
  `modelo` varchar(100) NOT NULL,
  `descripcion` text NOT NULL,
  `estado` tinyint(1) NOT NULL,
  `ultimo_mante` date NOT NULL,
  `fecregistro` datetime NOT NULL,
  `usuario_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `lectores` (`id`, `codigo`, `fabricante_id`, `modelo`, `descripcion`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('1', '122', '1', 'modelo del lector 1', 'descripcion del lector 1', '1', '2018-06-11', '2018-06-12 14:32:29', '1');


#
# TABLE STRUCTURE FOR: lectores_mantenimientos
#

DROP TABLE IF EXISTS `lectores_mantenimientos`;

CREATE TABLE `lectores_mantenimientos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lector_id` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `tecnico` varchar(250) NOT NULL,
  `descripcion` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `lectores_mantenimientos` (`id`, `lector_id`, `fecha`, `tecnico`, `descripcion`) VALUES ('1', '1', '2018-06-11', 'Jose Luis Fernandez', 'cambiode lector');


#
# TABLE STRUCTURE FOR: logs
#

DROP TABLE IF EXISTS `logs`;

CREATE TABLE `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` datetime NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `modulo` varchar(200) NOT NULL,
  `accion` varchar(200) NOT NULL,
  `descripcion` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=179 DEFAULT CHARSET=latin1;

INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('1', '2018-06-13 05:05:38', '1', 'Usuarios', '', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('2', '2018-06-13 05:05:45', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('3', '2018-06-13 05:14:54', '1', 'Computadoras', '', 'Inserción de nueva Computadora con Codigo 0991');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('4', '2018-06-13 05:15:15', '1', 'Computadoras', '', 'Actualización de la Computadora con Codigo 991');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('5', '2018-06-13 05:15:39', '1', 'Computadoras', '', 'Registro de Mantenimiento a la Computadora con Codigo 991');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('6', '2018-06-13 15:23:48', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('7', '2018-06-14 21:11:29', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('8', '2018-06-16 15:21:35', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('9', '2018-06-17 04:07:29', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('10', '2018-06-17 06:57:13', '1', 'Computadoras', '', 'Inserción de nueva Computadora con Codigo 011-1012');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('11', '2018-06-17 06:59:07', '1', 'Computadoras', '', 'Actualización de la Computadora con Codigo 11');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('12', '2018-06-17 14:46:09', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('13', '2018-06-18 03:55:35', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('14', '2018-06-18 15:15:11', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('15', '2018-06-19 04:31:01', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('16', '2018-06-20 16:08:01', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('17', '2018-06-22 06:50:04', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('18', '2018-06-22 16:03:39', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('19', '2018-06-22 20:43:19', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('20', '2018-06-23 16:37:40', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('21', '2018-06-23 19:46:13', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('22', '2018-06-24 03:07:26', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('23', '2018-06-24 04:41:51', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('24', '2018-06-24 06:46:02', '1', 'Computadoras', '', 'Inserción de nueva Computadora con Codigo 0012112');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('25', '2018-06-24 15:12:25', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('26', '2018-06-24 17:04:30', '1', 'Computadoras', '', 'Actualización de la Computadora con Codigo 12');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('27', '2018-06-24 20:47:26', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('28', '2018-06-25 04:59:39', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('29', '2018-06-25 16:25:16', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('30', '2018-06-25 18:10:05', '1', 'Usuarios', '', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('31', '2018-06-25 18:38:59', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('32', '2018-06-25 19:50:49', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('33', '2018-06-26 05:50:03', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('34', '2018-06-26 14:41:49', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('35', '2018-06-26 20:26:12', '1', 'Monitores', '', 'Eliminación del Monitor con Codigo ');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('36', '2018-06-26 20:26:47', '1', 'Monitores', '', 'Eliminación del Monitor con Codigo ');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('37', '2018-06-26 20:28:59', '1', 'Monitores', '', 'Actualización del Monitor con Codigo 10012');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('38', '2018-06-26 20:29:05', '1', 'Monitores', '', 'Eliminación del Monitor con Codigo ');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('39', '2018-06-26 20:31:04', '1', 'Monitores', '', 'Actualización del Monitor con Codigo 10012');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('40', '2018-06-26 20:31:08', '1', 'Monitores', '', 'Eliminación del Monitor con Codigo 10012');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('41', '2018-06-26 20:31:17', '1', 'Impresoras', '', 'Eliminación de la Impresoras con Codigo 10012');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('42', '2018-06-26 20:31:29', '1', 'Tablets', '', 'Eliminación de la Tablet con Codigo 10012');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('43', '2018-06-26 20:31:42', '1', 'Proyectos', '', 'Eliminación del Proyector con Codigo 100143');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('44', '2018-06-26 20:31:47', '1', 'Proyectos', '', 'Actualización del Proyector con Codigo 100143');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('45', '2018-06-26 20:31:54', '1', 'Lector de Barra', '', 'Eliminación del Lector con Codigo 122');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('46', '2018-06-26 20:31:59', '1', 'Lector de Barra', '', 'Actualización del Lector con Codigo 122');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('47', '2018-06-26 20:32:19', '1', 'Impresoras', '', 'Actualización de la Impresora con Codigo 10012');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('48', '2018-06-26 20:32:36', '1', 'Monitores', '', 'Actualización del Monitor con Codigo 19122');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('49', '2018-06-26 20:32:45', '1', 'Monitores', '', 'Actualización del Monitor con Codigo 19122');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('50', '2018-06-26 20:32:58', '1', 'Monitores', '', 'Actualización del Monitor con Codigo 10012');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('51', '2018-06-28 15:50:37', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('52', '2018-06-30 23:48:41', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('53', '2018-07-01 14:57:20', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('54', '2018-07-03 17:57:08', '1', 'Usuarios', '', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('55', '2018-07-03 17:57:14', '3', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('56', '2018-07-03 17:57:40', '3', 'Usuarios', '', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('57', '2018-07-30 16:01:20', '2', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('58', '2018-07-30 16:02:10', '2', 'Usuarios', '', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('59', '2018-07-30 16:02:16', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('60', '2018-08-14 20:06:34', '2', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('61', '2019-09-11 17:54:22', '4', 'Fabricantes', '', 'Actualización del Fabricante Chipset ');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('62', '2019-09-11 17:58:12', '4', 'Fincas', '', 'Actualización de la Finca Propio');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('63', '2019-09-11 17:59:09', '4', 'Fincas', '', 'Inserción de la Finca Arrendado');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('64', '2019-09-11 18:02:43', '4', 'Fincas', '', 'Inserción de la Finca prueba');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('65', '2019-09-11 18:03:03', '4', 'Fincas', '', 'Actualización de la Finca prueba');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('66', '2019-09-11 18:03:15', '4', 'Fincas', '', 'Actualización de la Finca prueba1');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('67', '2019-09-11 18:04:39', '4', 'Usuarios', '', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('68', '2019-09-11 18:06:14', '4', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('69', '2019-09-11 19:27:13', '4', 'Antivirus', '', 'Actualización del antivirus Avast 8');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('70', '2019-09-11 19:39:56', '4', 'Antivirus', '', 'Inserción del antivirus Prueba');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('71', '2019-09-11 19:40:09', '4', 'Antivirus', '', 'Eliminación del antivirus ');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('72', '2019-09-11 19:44:14', '4', 'Cargos', '', 'Inserción del cargo Prueba');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('73', '2019-09-11 19:53:24', '4', 'Cargos', '', 'Eliminación del cargo Prueba');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('74', '2019-09-11 19:53:35', '4', 'Cargos', '', 'Eliminación del cargo Prueba');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('75', '2019-09-11 19:58:14', '4', 'Cargos', '', 'Inserción del cargo dsfwfw');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('76', '2019-09-11 19:58:25', '4', 'Cargos', '', 'Eliminación del cargo dsfwfw');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('77', '2019-09-11 20:00:14', '4', 'Cargos', '', 'Eliminación del cargo Prueba');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('78', '2019-09-11 20:00:23', '4', 'Cargos', '', 'Eliminación del cargo dsfwfw');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('79', '2019-09-11 20:01:18', '4', 'Cargos', '', 'Actualización del cargo dsfwfw2341');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('80', '2019-09-11 20:01:22', '4', 'Cargos', '', 'Eliminación del cargo dsfwfw2341');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('81', '2019-09-11 20:04:58', '4', 'Cargos', '', 'Eliminación del cargo dsfwfw2341');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('82', '2019-09-11 20:05:12', '4', 'Cargos', '', 'Eliminación del cargo Prueba');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('83', '2019-09-11 20:05:42', '4', 'Cargos', '', 'Actualización del cargo Empleado');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('84', '2019-09-11 20:05:48', '4', 'Cargos', '', 'Actualización del cargo Dirección');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('85', '2019-09-11 21:24:16', '4', 'Usuarios', '', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('86', '2019-09-11 21:24:25', '4', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('87', '2019-09-11 21:32:01', '4', 'Usuarios', '', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('88', '2019-09-11 21:33:00', '4', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('89', '2019-09-11 21:55:19', '4', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('90', '2019-09-12 17:48:11', '4', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('91', '2019-09-12 17:53:13', '4', 'Computadoras', '', 'Registro de Mantenimiento a la Computadora con Codigo 9121');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('92', '2019-09-12 19:13:53', '4', 'Computadoras', '', 'Actualización de la Computadora con Codigo 901125');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('93', '2019-09-12 19:13:56', '4', 'Computadoras', '', 'Actualización de la Computadora con Codigo 901125');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('94', '2019-09-12 20:10:45', '4', 'Computadoras', '', 'Eliminación de la Computadora con Codigo 901125');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('95', '2019-09-12 21:11:28', '4', 'Propietario', '', 'Inserción del propietario A A ');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('96', '2019-09-12 21:14:24', '4', 'Propietario', '', 'Actualización del propietario A A A');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('97', '2019-09-12 21:14:28', '4', 'Propietario', '', 'Eliminación del propietario A');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('98', '2019-09-12 21:14:35', '4', 'Propietario', '', 'Eliminación del propietario A');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('99', '2019-09-12 21:15:42', '4', 'Propietario', '', 'Eliminación del propietario A');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('100', '2019-09-12 21:15:50', '4', 'Propietario', '', 'Eliminación del propietario A');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('101', '2019-09-12 21:16:01', '4', 'Propietario', '', 'Eliminación del propietario A');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('102', '2019-09-12 21:16:31', '4', 'Propietario', '', 'Actualización del propietario A A A');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('103', '2019-09-12 21:16:48', '4', 'Propietario', '', 'Actualización del propietario A A A');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('104', '2019-09-12 21:16:54', '4', 'Propietario', '', 'Eliminación del propietario A');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('105', '2019-09-12 21:19:24', '4', 'Propietario', '', 'Eliminación del propietario A');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('106', '2019-09-13 18:06:53', '4', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('107', '2019-09-17 17:33:24', '4', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('108', '2019-09-17 19:47:43', '4', 'Usuarios', '', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('109', '2019-09-17 19:47:48', '4', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('110', '2019-09-17 19:47:52', '4', 'Usuarios', '', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('111', '2019-09-17 19:48:05', '4', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('112', '2019-09-18 17:34:26', '4', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('113', '2019-09-18 18:25:53', '4', 'Usuarios', '', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('114', '2019-09-18 18:26:18', '4', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('115', '2019-09-18 18:38:30', '4', 'Usuarios', '', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('116', '2019-09-18 18:38:51', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('117', '2019-09-18 18:39:29', '1', 'Usuarios', '', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('118', '2019-09-18 18:39:30', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('119', '2019-09-18 18:56:18', '1', 'Antivirus', '', 'Eliminación del antivirus ');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('120', '2019-09-18 18:56:36', '1', 'Ip', '', 'Eliminación de IP ');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('121', '2019-09-18 19:00:07', '1', 'Ip', '', 'Eliminación de IP 172.17.124.172');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('122', '2019-09-18 19:00:22', '1', 'Ip', '', 'Eliminación de IP 172.17.124.174');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('123', '2019-09-18 19:00:28', '1', 'Ip', '', 'Actualización de IP 172.17.124.174');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('124', '2019-09-18 19:00:33', '1', 'Ip', '', 'Actualización de IP 172.17.124.172');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('125', '2019-09-18 19:37:41', '1', 'Usuarios', '', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('126', '2019-09-18 19:38:32', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('127', '2019-09-18 22:07:18', '1', 'Usuarios', '', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('128', '2019-09-19 17:45:51', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('129', '2019-09-19 17:45:58', '1', 'Usuarios', '', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('130', '2019-09-19 17:47:10', '5', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('131', '2019-09-19 17:48:13', '5', 'Usuarios', '', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('132', '2019-09-19 17:49:27', '6', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('133', '2019-09-19 18:56:06', '6', 'Usuarios', '', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('134', '2019-09-20 18:15:38', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('135', '2019-09-20 20:24:06', '1', 'Presentaciones', '', 'Inserción de un nuevo modelo con el nombre HP');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('136', '2019-09-20 20:24:37', '1', 'Presentaciones', '', 'Actualización de modelo LENOVO');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('137', '2019-09-20 20:25:33', '1', 'Modelo', '', 'Actualización de modelo MAC');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('138', '2019-09-20 20:26:21', '1', 'Modelo', '', 'Actualización de modelo MAC');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('139', '2019-09-26 17:45:17', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('140', '2019-09-26 18:12:50', '1', 'Categoria', '', 'Inserción de la Categoria MAC');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('141', '2019-09-26 18:13:00', '1', 'Categoria', '', 'Eliminación de la Categoria MAC');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('142', '2019-09-26 18:13:19', '1', 'Categoria', '', 'Actualización de la Categoria MAC EDIT');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('143', '2019-09-26 18:14:12', '1', 'Categoria', '', 'Actualización de la Categoria MAC EDIT');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('144', '2019-09-26 18:29:27', '1', 'Recurso de Red', '', 'Inserción del Recurso de Red Nuevo recurso');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('145', '2019-09-26 18:30:05', '1', 'Recurso de Red', '', 'Inserción del Recurso de Red Nuevo');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('146', '2019-09-26 18:30:20', '1', 'Recurso de Red', '', 'Eliminación del Recurso de Red Nuevo');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('147', '2019-09-26 18:31:03', '1', 'Recurso de Red', '', 'Actualización del Recurso de Red NuevoEdit');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('148', '2019-09-26 18:31:39', '1', 'Recurso de Red', '', 'Actualización del Recurso de Red NuevoEditado');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('149', '2019-09-26 18:31:51', '1', 'Recurso de Red', '', 'Eliminación del Recurso de Red NuevoEditado');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('150', '2019-09-26 18:32:00', '1', 'Recurso de Red', '', 'Actualización del Recurso de Red NuevoEditado2');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('151', '2019-09-26 19:55:54', '1', 'Usuarios', '', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('152', '2019-09-26 19:56:29', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('153', '2019-09-26 19:56:39', '1', 'Usuarios', '', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('154', '2019-09-26 19:56:43', '5', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('155', '2019-09-26 19:56:57', '5', 'Usuarios', '', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('156', '2019-09-26 19:57:01', '6', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('157', '2019-09-26 19:57:35', '6', 'Usuarios', '', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('158', '2019-09-26 20:08:24', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('159', '2019-09-26 20:08:45', '1', 'Usuarios', '', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('160', '2019-09-26 20:11:26', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('161', '2019-09-26 20:32:01', '1', 'Computadoras', '', 'Inserción de nueva Computadora con Codigo 46342341');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('162', '2019-09-26 20:33:01', '1', 'Computadoras', '', 'Eliminación de la Computadora con Codigo 46342341');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('163', '2019-09-26 20:40:29', '1', 'Computadoras', '', 'Actualización de la Computadora con Codigo 46342341');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('164', '2019-09-26 20:46:25', '1', 'Usuarios', '', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('165', '2019-09-26 20:46:40', '9', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('166', '2019-09-26 20:48:55', '9', 'Usuarios', '', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('167', '2019-09-26 20:49:24', '8', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('168', '2019-09-26 21:42:52', '8', 'Usuarios', '', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('169', '2019-09-26 21:42:58', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('170', '2019-09-27 17:25:10', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('171', '2019-09-27 18:03:14', '1', 'Usuarios', '', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('172', '2019-09-27 18:03:19', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('173', '2019-09-27 18:04:00', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('174', '2019-09-27 18:11:48', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('175', '2019-09-27 18:12:05', '1', 'Usuarios', '', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('176', '2019-09-27 18:12:16', '5', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('177', '2019-09-27 18:12:43', '5', 'Areas', '', 'Inserción del area informatica');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('178', '2019-09-27 18:13:42', '9', 'Usuarios', '', 'Inicio de sesión');


#
# TABLE STRUCTURE FOR: memorias
#

DROP TABLE IF EXISTS `memorias`;

CREATE TABLE `memorias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `capacidad` varchar(250) NOT NULL,
  `fabricante_id` int(11) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `memorias` (`id`, `capacidad`, `fabricante_id`, `estado`) VALUES ('1', '4000 mb', '1', '1');
INSERT INTO `memorias` (`id`, `capacidad`, `fabricante_id`, `estado`) VALUES ('2', '8000 mb', '1', '0');


#
# TABLE STRUCTURE FOR: monitores
#

DROP TABLE IF EXISTS `monitores`;

CREATE TABLE `monitores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` int(11) NOT NULL,
  `tamaño` varchar(100) NOT NULL,
  `proveedor_id` int(11) NOT NULL,
  `finca_id` int(11) NOT NULL,
  `area_id` int(11) NOT NULL,
  `contacto` varchar(250) NOT NULL,
  `fabricante_id` int(11) NOT NULL,
  `serial_fabricante` varchar(100) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `bitacora` text NOT NULL,
  `estado` tinyint(1) NOT NULL,
  `ultimo_mante` text DEFAULT NULL,
  `fecregistro` datetime NOT NULL,
  `usuario_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('1', '19122', '19\' pulgadas', '1', '1', '2', 'Jose Perez', '1', '11201212', 'referencia de la monior 01', 'esta funcionable', '1', '2018-06-11', '2018-06-10 03:08:09', '1');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('2', '10012', '19\' pulgadas', '2', '1', '1', 'Maria Cortez', '1', '11201212', 'refencia 01', 'esta funcionable', '1', '2018-06-11', '2018-06-11 08:26:22', '1');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('3', '7870', '19 pulgadas', '1', '1', '1', 'Carmen Salinas', '1', '1991121', 'referenca 01', 'esta funcionable', '1', NULL, '0000-00-00 00:00:00', '1');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('4', '7871', '19 pulgadas', '1', '1', '2', 'Carmen Salinas', '1', '1991121', 'referenca 01', 'No muestra pantalla', '1', NULL, '0000-00-00 00:00:00', '1');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('5', '7872', '19 pulgadas', '1', '1', '1', 'Carmen Salinas', '1', '1991121', 'referenca 01', '43311.770833333', '1', NULL, '0000-00-00 00:00:00', '1');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('6', '7873', '19 pulgadas', '1', '1', '2', 'Carmen Salinas', '1', '1991121', 'referenca 01', 'No muestra pantalla', '1', NULL, '0000-00-00 00:00:00', '1');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('7', '7874', '19 pulgadas', '1', '1', '1', 'Carmen Salinas', '1', '1991121', 'referenca 01', '43311.770833333', '1', NULL, '1970-01-01 01:00:00', '1');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('8', '7875', '19 pulgadas', '1', '1', '2', 'Carmen Salinas', '1', '1991121', 'referenca 01', 'No muestra pantalla', '1', NULL, '1970-01-01 01:00:00', '1');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('9', '7876', '19 pulgadas', '1', '1', '1', 'Carmen Salinas', '1', '1991121', 'referenca 01', '43311.770833333', '1', NULL, '2018-07-30 18:30:00', '1');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('10', '7877', '19 pulgadas', '1', '1', '2', 'Carmen Salinas', '1', '1991121', 'referenca 01', 'No muestra pantalla', '1', NULL, '2018-07-31 18:30:00', '1');


#
# TABLE STRUCTURE FOR: monitores_mantenimientos
#

DROP TABLE IF EXISTS `monitores_mantenimientos`;

CREATE TABLE `monitores_mantenimientos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `monitor_id` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `tecnico` varchar(250) NOT NULL,
  `descripcion` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `monitores_mantenimientos` (`id`, `monitor_id`, `fecha`, `tecnico`, `descripcion`) VALUES ('1', '1', '2018-06-14', 'Jose Luis Fernandez Aguilar', 'Limpieza interna');
INSERT INTO `monitores_mantenimientos` (`id`, `monitor_id`, `fecha`, `tecnico`, `descripcion`) VALUES ('2', '2', '2018-06-11', 'Jhon Manrique', 'Limpieza interna');
INSERT INTO `monitores_mantenimientos` (`id`, `monitor_id`, `fecha`, `tecnico`, `descripcion`) VALUES ('3', '1', '2018-06-11', 'Jhon Manrique', 'Cambio de Repuesto');


#
# TABLE STRUCTURE FOR: office
#

DROP TABLE IF EXISTS `office`;

CREATE TABLE `office` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `office` (`id`, `nombre`, `estado`) VALUES ('1', 'Office 2013', '1');
INSERT INTO `office` (`id`, `nombre`, `estado`) VALUES ('2', 'Office 2016', '0');


#
# TABLE STRUCTURE FOR: presentaciones
#

DROP TABLE IF EXISTS `presentaciones`;

CREATE TABLE `presentaciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(250) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `presentaciones` (`id`, `nombre`, `estado`) VALUES ('1', 'MAC', '1');
INSERT INTO `presentaciones` (`id`, `nombre`, `estado`) VALUES ('2', 'LENOVO', '0');
INSERT INTO `presentaciones` (`id`, `nombre`, `estado`) VALUES ('3', 'HP', '1');


#
# TABLE STRUCTURE FOR: procesadores
#

DROP TABLE IF EXISTS `procesadores`;

CREATE TABLE `procesadores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `referencia` varchar(250) NOT NULL,
  `velocidad` varchar(250) NOT NULL,
  `fabricante_id` int(11) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `procesadores` (`id`, `referencia`, `velocidad`, `fabricante_id`, `estado`) VALUES ('1', 'refencia 01', '100 mb', '1', '1');


#
# TABLE STRUCTURE FOR: propietarios
#

DROP TABLE IF EXISTS `propietarios`;

CREATE TABLE `propietarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(250) NOT NULL,
  `apMat` varchar(250) NOT NULL,
  `apPat` varchar(250) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('1', 'Adolfo', 'C', 'Fonseca', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('2', 'Raúl', 'Silva', 'Inventado', '1');
INSERT INTO `propietarios` (`id`, `nombre`, `apMat`, `apPat`, `estado`) VALUES ('3', 'Ivan', 'Ortiz', 'Rosales', '1');


#
# TABLE STRUCTURE FOR: proveedores
#

DROP TABLE IF EXISTS `proveedores`;

CREATE TABLE `proveedores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(250) NOT NULL,
  `nit` varchar(100) NOT NULL,
  `direccion` varchar(250) NOT NULL,
  `correo` varchar(250) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `proveedores` (`id`, `nombre`, `nit`, `direccion`, `correo`, `estado`) VALUES ('1', 'Proveedor 01', '120121', 'Calle Pichincha 310', 'proveedor@gmail.com', '1');
INSERT INTO `proveedores` (`id`, `nombre`, `nit`, `direccion`, `correo`, `estado`) VALUES ('2', 'Proveedor 2', '', '', '', '0');


#
# TABLE STRUCTURE FOR: proyectores
#

DROP TABLE IF EXISTS `proyectores`;

CREATE TABLE `proyectores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` int(11) NOT NULL,
  `fabricante_id` int(11) NOT NULL,
  `modelo` varchar(100) NOT NULL,
  `descripcion` text NOT NULL,
  `estado` tinyint(1) NOT NULL,
  `ultimo_mante` date DEFAULT NULL,
  `fecregistro` datetime NOT NULL,
  `usuario_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `proyectores` (`id`, `codigo`, `fabricante_id`, `modelo`, `descripcion`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('1', '100143', '1', 'modelo proyector 1', 'Descripcion del proyector 1', '1', '2018-06-11', '2018-06-03 12:30:24', '1');


#
# TABLE STRUCTURE FOR: proyectores_mantenimientos
#

DROP TABLE IF EXISTS `proyectores_mantenimientos`;

CREATE TABLE `proyectores_mantenimientos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proyector_id` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `tecnico` date NOT NULL,
  `descripcion` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `proyectores_mantenimientos` (`id`, `proyector_id`, `fecha`, `tecnico`, `descripcion`) VALUES ('1', '1', '2018-06-11', '0000-00-00', 'Cambio de Ventilador');


#
# TABLE STRUCTURE FOR: recursored
#

DROP TABLE IF EXISTS `recursored`;

CREATE TABLE `recursored` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(100) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `recursored` (`id`, `descripcion`, `estado`) VALUES ('1', 'Correo electrónico', '1');
INSERT INTO `recursored` (`id`, `descripcion`, `estado`) VALUES ('2', 'Equipo', '1');
INSERT INTO `recursored` (`id`, `descripcion`, `estado`) VALUES ('3', 'Terabyte', '1');


#
# TABLE STRUCTURE FOR: roles
#

DROP TABLE IF EXISTS `roles`;

CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) NOT NULL,
  `descripcion` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `roles` (`id`, `nombre`, `descripcion`) VALUES ('1', 'Administrador', '');
INSERT INTO `roles` (`id`, `nombre`, `descripcion`) VALUES ('2', 'Usuario', '');
INSERT INTO `roles` (`id`, `nombre`, `descripcion`) VALUES ('3', 'Reportes', '');


#
# TABLE STRUCTURE FOR: sistemas
#

DROP TABLE IF EXISTS `sistemas`;

CREATE TABLE `sistemas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(100) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `sistemas` (`id`, `descripcion`, `estado`) VALUES ('1', 'Windows 8', '1');
INSERT INTO `sistemas` (`id`, `descripcion`, `estado`) VALUES ('2', 'Windows 10', '1');


#
# TABLE STRUCTURE FOR: tablets
#

DROP TABLE IF EXISTS `tablets`;

CREATE TABLE `tablets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` int(11) NOT NULL,
  `fabricante_id` int(11) NOT NULL,
  `modelo` varchar(100) NOT NULL,
  `descripcion` varchar(250) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  `ultimo_mante` date DEFAULT NULL,
  `fecregistro` datetime NOT NULL,
  `usuario_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `tablets` (`id`, `codigo`, `fabricante_id`, `modelo`, `descripcion`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('1', '10012', '1', 'modelo 01', 'descripcion de la tablet 01', '0', '2018-06-11', '2018-06-10 09:47:28', '1');
INSERT INTO `tablets` (`id`, `codigo`, `fabricante_id`, `modelo`, `descripcion`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('2', '100143', '1', 'modelo 01', 'descripcion de la tablet 02', '1', NULL, '2018-06-10 13:24:33', '1');
INSERT INTO `tablets` (`id`, `codigo`, `fabricante_id`, `modelo`, `descripcion`, `estado`, `ultimo_mante`, `fecregistro`, `usuario_id`) VALUES ('3', '911', '1', 'modelo proyector 01', 'Descripcion del proyector 01', '1', NULL, '2018-06-11 11:29:33', '1');


#
# TABLE STRUCTURE FOR: tablets_mantenimientos
#

DROP TABLE IF EXISTS `tablets_mantenimientos`;

CREATE TABLE `tablets_mantenimientos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tablet_id` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `tecnico` varchar(250) NOT NULL,
  `descripcion` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tablets_mantenimientos` (`id`, `tablet_id`, `fecha`, `tecnico`, `descripcion`) VALUES ('1', '1', '2018-06-11', 'Jhon Manrique', 'Cambuo de Carcasa');


#
# TABLE STRUCTURE FOR: usuarios
#

DROP TABLE IF EXISTS `usuarios`;

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombres` varchar(200) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(100) NOT NULL,
  `cedula` int(11) NOT NULL,
  `sexo` varchar(100) NOT NULL,
  `rol_id` int(11) DEFAULT NULL,
  `estado` tinyint(1) NOT NULL,
  `imagen` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO `usuarios` (`id`, `nombres`, `email`, `password`, `cedula`, `sexo`, `rol_id`, `estado`, `imagen`) VALUES ('1', 'Administrador', 'admin@admin.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '10000', 'M', '1', '1', 'cultura1-compressor1.jpg');
INSERT INTO `usuarios` (`id`, `nombres`, `email`, `password`, `cedula`, `sexo`, `rol_id`, `estado`, `imagen`) VALUES ('5', 'Usuario', 'user@user.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '87328', 'M', '2', '1', 'imagen_masculino.jpg');
INSERT INTO `usuarios` (`id`, `nombres`, `email`, `password`, `cedula`, `sexo`, `rol_id`, `estado`, `imagen`) VALUES ('6', 'Reportes', 'reporte@reporte.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '93271', 'M', '3', '1', 'imagen_masculino.jpg');
INSERT INTO `usuarios` (`id`, `nombres`, `email`, `password`, `cedula`, `sexo`, `rol_id`, `estado`, `imagen`) VALUES ('7', 'Fabiola Guzmán', 'fabiola@fonca.com', '11e776696e454cd696d135d9aa5de378cc1eb8da', '201901100', 'F', '3', '1', 'imagen_femenino.jpg');
INSERT INTO `usuarios` (`id`, `nombres`, `email`, `password`, `cedula`, `sexo`, `rol_id`, `estado`, `imagen`) VALUES ('8', 'Victor Adrián Martínez', 'vic.martinez@fonca.com', '4f5e7f4f938760cd314293f888ae4288e6e3e6f8', '201902101', 'M', '2', '1', 'imagen_masculino.jpg');
INSERT INTO `usuarios` (`id`, `nombres`, `email`, `password`, `cedula`, `sexo`, `rol_id`, `estado`, `imagen`) VALUES ('9', 'Raúl Fonseca', 'r.fonseca@fonca.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '201903103', 'M', '1', '1', 'imagen_masculino.jpg');
INSERT INTO `usuarios` (`id`, `nombres`, `email`, `password`, `cedula`, `sexo`, `rol_id`, `estado`, `imagen`) VALUES ('10', 'Adolfo Silva', 'a.silva@fonca.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '2019041004', 'M', '1', '1', 'imagen_masculino.jpg');


